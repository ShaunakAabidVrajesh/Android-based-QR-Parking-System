# QR CODE Scanner & Generator

A new Flutter project on QR Code Scanning and generating it for perosnal and business usage.

## Getting Started

You need to create a new flutter Project with choice of your name.
You need to add some plugins named as:

<a class="github-button" href="https://pub.dev/packages/barcode_scan">A. barcode_scan 2.0.1</a>
<br>
<a class="github-button" href="https://pub.dev/packages/qr_flutter">B. qr_flutter 3.2.0</a>

After running flutter packages get,

Now its time to go for some coding...

1. I have built and interface with two buttons that generate and scan the QR Code.

<h3>Main Interface HomePage.dart</h3> 
<img src="https://github.com/neon97/QR-CODE-Scanner-Generator/blob/master/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2011%20Pro%20Max%20-%202020-04-11%20at%2010.18.34.png?raw=true"  width="200" >
</img>

2. Getting to the Next creating Scanpage.dart and GeneratePage.dart

<a class="github-button" href="https://www.youtube.com/watch?v=kd1CLYLymbI">--------------Wait, a sec why everything here, You can find the whole content here @ medium @youtube ----------------</a>

Dont forget to give a Clap to Medium Page and Kudos to this repo if it has helped you,

Follow me on :
<br>
<a class="github-button" href="https://www.linkedin.com/in/raj-vishwakarma0159">@linkedin</a>
<br>
<a class="github-button" href="https://www.facebook.com/edutechload/">@facebook</a>
<br>
<a class="github-button" href="https://www.youtube.com/edutech%20load">@youtube</a>
<br>
<a class="github-button" href="https://medium.com/@dc.vishwakarma.raj">@medium</a>
<br>
<a class="github-button" href="https://github.com/neon97">@github</a>

I have uploaded Screenshots of the UI.

<h3>Scanner Page scan.dart</h3> 
<img src="https://github.com/neon97/QR-CODE-Scanner-Generator/blob/master/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2011%20Pro%20Max%20-%202020-04-11%20at%2010.18.40.png?raw=true"  width="200" >
</img>

<h3>Generator Page generate.dart</h3> 
<img src="https://github.com/neon97/QR-CODE-Scanner-Generator/blob/master/screenshots/Simulator%20Screen%20Shot%20-%20iPhone%2011%20Pro%20Max%20-%202020-04-11%20at%2010.18.53.png?raw=true"  width="200" >
</img>
