import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qrcode/login.dart';


class SplashScreen extends StatefulWidget {

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {



  Future<FirebaseUser> user=FirebaseAuth.instance.currentUser();
  @override
  void initState(){
Future.delayed(Duration(seconds:2),(){
  FirebaseAuth.instance.currentUser().then((user) => {
   Navigator.pushReplacement(context, MaterialPageRoute(builder: (contxt)=>login()))
  });
});

      super.initState();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          color: Colors.blueAccent,
        ),
        child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  'assets/images/qr-code.png',
                  width:200,height:200,
                ),
                Text('QPARK',
                  style: TextStyle(fontWeight: FontWeight.bold,fontFamily: 'Roboto',fontSize: 30,color:Colors.white),
                ),
                Text('Parking Made Easy',style: TextStyle(fontSize: 10,color:Colors.white),),
              ],
            )),
      ),
    );
  }

}
