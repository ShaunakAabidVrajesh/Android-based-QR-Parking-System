import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qrcode/cancelbookings.dart';
import 'package:qrcode/scanexit.dart';
import 'package:qrcode/tabview.dart';
import 'package:qrcode/homePage.dart';
import 'package:qrcode/login.dart';
import 'package:qrcode/myapp.dart';
import 'package:qrcode/scan.dart';
import 'package:qrcode/bookings.dart';

import 'navigationDrawer.dart';

class PreHomePage extends StatefulWidget {
  String parkingid, phno;
  PreHomePage({Key key, this.parkingid, this.phno}) : super(key: key);
  @override
  _PreHomePageState createState() =>
      new _PreHomePageState(this.parkingid, this.phno);
}

class _PreHomePageState extends State<PreHomePage> {
  String parkingid, phno;
  _PreHomePageState(this.parkingid, this.phno);

  @override
  Widget build(BuildContext context) {
    return new WillPopScope(
      onWillPop: () async {
        return showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text('Are you sure?'),
              content: Text("Do you want to Exit App"),
              actions: [
                new TextButton(
                    onPressed: () => Navigator.of(context).pop(false),
                    child: Text('No')),
                new TextButton(
                    onPressed: () {
                      SystemChannels.platform
                          .invokeMethod('SystemNavigator.pop');
                      Navigator.of(context).pop(true);
                    },
                    child: Text('Yes')),
              ],
            );
          },
        ) ??
            false;
      },
      child: new Scaffold(
        appBar: AppBar(
          title: Text("Homepage"),
          centerTitle: true,
          elevation: 10,
          backgroundColor: Colors.blueAccent,
        ),
        drawer:new  navigationDrawer(parkingid: parkingid,),
        body: new Container(
          height: MediaQuery.of(context).size.height,
          width: MediaQuery.of(context).size.width,
          padding: EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              SizedBox(
                height: MediaQuery.of(context).size.height * 0.20, //130,
                child: Image.asset('assets/images/database.png'),
              ),
              FlatButton(
                padding: EdgeInsets.all(15.0),
                onPressed: () async {
                  print(parkingid);
                  Navigator.push(
                      (context),
                      MaterialPageRoute(
                          builder: (context) =>
                              bookingdetails(parkname: parkingid)));
                },
                child: Text(
                  "New Booking",
                  style:
                      TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                ),
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.blue, width: 3.0),
                    borderRadius: BorderRadius.circular(20.0)),
              ),
              FlatButton(
                padding: EdgeInsets.all(15.0),
                onPressed: () async {
                  Navigator.push(
                      (context),
                      MaterialPageRoute(
                          builder: (context) => ScanPage(parkid: parkingid)));
                },
                child: Text(
                  "Scan",
                  style:
                      TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                ),
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.blue, width: 3.0),
                    borderRadius: BorderRadius.circular(20.0)),
              ),

              //flatButton("Scan", ScanPage()),
              //SizedBox(
              //   height: 20.0,
              // ),
              /*
              flatButton("History", tabs(parkid: parkingid)),
              SizedBox(
                height: 20.0,
              ),
              flatButton("Back", ScanPage()), */
              FlatButton(
                padding: EdgeInsets.all(15.0),
                onPressed: () async {
                  print(parkingid);
                  Navigator.push(
                      (context),
                      MaterialPageRoute(
                          builder: (context) => tabs(parkid: parkingid)));
                },
                child: Text(
                  "History",
                  style:
                      TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                ),
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.blue, width: 3.0),
                    borderRadius: BorderRadius.circular(20.0)),
              ),
              FlatButton(
                padding: EdgeInsets.all(15.0),
                onPressed: () async {
                  Navigator.push(
                      (context),
                      MaterialPageRoute(
                          builder: (context) => ScanexitPage(parkid: parkingid)));
                },
                child: Text(
                  "Exit Scan",
                  style:
                      TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
                ),
                shape: RoundedRectangleBorder(
                    side: BorderSide(color: Colors.blue, width: 3.0),
                    borderRadius: BorderRadius.circular(20.0)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget flatButton(String text, Widget widget) {
    return FlatButton(
      padding: EdgeInsets.all(15.0),
      onPressed: () async {
        Navigator.of(context)
            .push(MaterialPageRoute(builder: (context) => widget));
      },
      child: Text(
        text,
        style: TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
      ),
      shape: RoundedRectangleBorder(
          side: BorderSide(color: Colors.blue, width: 3.0),
          borderRadius: BorderRadius.circular(20.0)),
    );
  }
}
