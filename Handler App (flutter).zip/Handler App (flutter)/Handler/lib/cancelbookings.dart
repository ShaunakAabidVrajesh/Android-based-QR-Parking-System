import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';

import 'historydetails.dart';

final FirebaseAuth auth = FirebaseAuth.instance;
var name, slotno, booktime, reservetime, address;
var dates=DateFormat.yMMMd().format(DateTime.now());
class cancelled extends StatefulWidget {
  String parkid;
  cancelled({Key key, this.parkid}) : super(key: key);
  @override
  _cancelledState createState() => _cancelledState(this.parkid);
}

class _cancelledState extends State<cancelled> {
  void initState() {
    // TODO: implement initStat
    //();
    //   Firebase();
    //
    super.initState();
  }


  String parkid;
  _cancelledState(this.parkid);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      /*appBar: AppBar(

        title: Text(
          "Booking History",
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blueAccent,
        elevation: 10,
        centerTitle: true,
        textTheme: Theme
            .of(context)
            .textTheme,
      ),
      drawer: navigationDrawer(),*/
      body: Center(
        child: Container(
          //  margin: EdgeInsets.only(top: 60),
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height * 1.5,

          child: StreamBuilder<QuerySnapshot>(
              stream: Firestore.instance
                  .collection('parkingDetails')
                  .document(parkid)
                  .collection('Slotsbooked').where('date' ,isEqualTo: dates.toString())
                  .where('bookingstatus', isEqualTo: 'Cancelled')
                  .orderBy("date", descending: true)
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError)
                  return new Text('Error: ${snapshot.error}');
                switch (snapshot.connectionState) {
                  case ConnectionState.waiting:
                    return Center(child: Center(child: new Text('Loading...')));
                  default:
                    return new GridView(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        // childAspectRatio: 0.60,
                        mainAxisSpacing: 15,
                        crossAxisSpacing: 15,
                      ),
                      padding: EdgeInsets.all(20),
                      scrollDirection: Axis.vertical,
                      children: snapshot.data.documents
                          .map((DocumentSnapshot document) {
                        return new CustomCard(
                          username: document['username'].toString().toUpperCase(),
                          booktime: document['booktime'],
                          parkname:document['parkingname'],
                          reserve: document['reserve'],
                          slotno: document['slotno'],
                          useraddress: document['address'],
                          date: document['date'].toString(),
                          qrid: document['qrid'],
                          vehicleno: document['vehicleno'],
                          parked: document['parked'],
                          booking: document['bookingstatus'],
                          // paymenytmode: document['fee'].toString(),
                          status: document['status'],
                          txnid: document['txnid'],
                          txtrefno: document['txtrefno'],
                          phno: document['userno'],
                          userid: document['userid'],
                          createdon:document['createdon'].toString(),
                        );
                      }).toList(),
                    );
                }
              }),
        ),
      ),
    );
  }
}
