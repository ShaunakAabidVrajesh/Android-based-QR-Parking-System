import 'dart:core';
import 'dart:math';

import 'package:flutter/services.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qrcode/receipt.dart';

// ignore: must_be_immutable
class paymentpage extends StatefulWidget {
  final String pname;

  Map<String, dynamic> data;

  var userid;
  paymentpage({
    Key key,
    this.pname,
    this.data,
  }) : super(key: key);
  @override
  _paymentpageState createState() => _paymentpageState(this.pname,this.data);
}

class _paymentpageState extends State<paymentpage> {

  var pname,upino,txnid;
  Map<String, dynamic> data;
  TextEditingController controller = TextEditingController();
  TextEditingController dcontroller = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  int _radioValue = 0;
  _paymentpageState(this.pname, this.data);
bool visible;
  String get parkid => pname;

  Map get d => data;


  final String transactionRef = Random.secure().nextInt(1 << 32).toString();
 // Map get values => data;

   _handleRadioValueChange(int value) {
    setState(() {
      _radioValue = value;

      switch (_radioValue) {
        case 0:
          setState(() {
            visible=false;
          });
          break;
        case 1:
          setState(() {
            visible=true;
          });
      /*    Firestore.instance
              .collection('parkingDetails')
              .document(parkid)
              .collection('Slotsbooked')
              .document(qrid)
              .updateData({'txnid':txnid,'txtrefno':upino});
          return  MaterialPageRoute(
              builder: (context) => MyRecipt(
                  qrid: qrid, parkid: parkid));*/
          break;
      }
    });
  }

  @override
  final skey = GlobalKey<ScaffoldState>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Payment'),
          backgroundColor: Colors.blueAccent,
          elevation: 10,
        ),
        body: Padding(
            padding: EdgeInsets.all(10),
            child: ListView(children: [
              Container(
                  alignment: Alignment.center,
                  padding: EdgeInsets.all(10),
                  margin: const EdgeInsets.only(top: 50),
                  child: Text(
                    'Payment Mode',
                    style: TextStyle(
                        color: Colors.red,
                        fontWeight: FontWeight.w500,
                        fontSize: 30),
                  )),
              new Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  new Radio(
                    value: 0,
                    groupValue: _radioValue,
                    onChanged: _handleRadioValueChange,
                  ),
                  new Text(
                    'Cash',
                    style: new TextStyle(fontSize: 16.0),
                  ),
                  new Radio(
                    value: 1,
                    groupValue: _radioValue,
                   onChanged: _handleRadioValueChange,
                  ),
                  new Text(
                    'UPI',
                    style: new TextStyle(
                      fontSize: 16.0,
                    ),
                  ),
                ],
              ),
              if (visible==true) Form(
                key: _formKey,
                child: Column(
                  children: <Widget>[

                    Padding(
                      padding: const EdgeInsets.all(15.0),
                      child: Container(
                        height: 60, //60,
                        decoration: BoxDecoration(

                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Padding(
                          padding: EdgeInsets.only(
                              left: 15, right: 15, top: 5),
                          child: TextFormField(
                              autofocus: true,
                              decoration: InputDecoration(
                                counterText: '',
                                border: InputBorder.none,
                                errorStyle: TextStyle(height: 0.3),
                                fillColor: Colors.white,
                                prefixIcon: Icon(
                                  Icons.phone,
                                ),

                              ),
                              maxLength: 10,
                              controller: controller,
                              keyboardType: TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              onChanged: (v){
                                setState(() {
                                  upino=v;
                                });
                              },
                              validator: (value) {
                                if (value.isEmpty) {
                                  return 'UPI Number must not be empty';
                                } else if (value.length != 10) {
                                  controller.clear();
                                  return 'Mobile Number must be 10 digit';
                                } else {
                                  setState(() {
                                    upino=value;
                                  });
                                  //to nAVIAGTE AFTER VERIFYING
                                }
                              }),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(10.0),
                      child: Container(
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        child: Padding(
                          padding: EdgeInsets.all(10.0),
                          child: TextFormField(
                            decoration: InputDecoration(
                              border: InputBorder.none,
                              fillColor: Colors.white,
                              prefixIcon: Icon(
                                Icons.wysiwyg_outlined,
                              ),
                              //  suffixIcon: Icon(Icons.check_circle_outline,color: Colors.black26,),
                              counterText: '',
                              hintText: 'Transaction Id',
                              errorStyle: TextStyle(height: 0.3),
                            ),
                            maxLength: 20,
                            autofocus: true,
                            keyboardType: TextInputType.text,
                            onChanged: (v){
                              setState(() {
                                txnid=v;
                              });
                            },
                            validator: (value) {
                              if (value.isEmpty) {
                                return 'Enter Transacion ID';
                              } else {
                                setState(() {
                                  txnid = value;
                                });
                                return null;
                              }
                              //to nAVIAGTE AFTER VERIFYING
                            },
                          ),
                        ),
                      ),
                    ),

                    SizedBox(
                      height: 50,
                    ),

                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(15),
                child: Container(
                  height: 60,
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                        primary: Colors.blueAccent,
                        elevation: 5,
                        shape: RoundedRectangleBorder(
                          borderRadius:
                          BorderRadius.circular(10.0),
                        )),
                    onPressed: () async {
                      //   final  CollectionReference slots=Firestore.instance.collection('parkingDetails').document(widget.docId).collection('Slotsavailable');
                      var qrid = d['qrid'];
                      _handleRadioValueChange(_radioValue);
                      print(_radioValue);
                      print(qrid);print(parkid);

                      final CollectionReference book =
                      Firestore.instance.collection('parkingDetails');
                      if(_radioValue==0){
                        Map <String,dynamic> data2={
                          'txtrefno': 'T' + transactionRef,
                          'txnid':'cash'
                        };
                       data2.addAll(data);
                        try {
                          await Firestore.instance
                              .collection('parkingDetails')
                              .document(parkid)
                              .collection('Slotsbooked')
                              .document(qrid)
                              .setData(data2
                            ).then((value) =>
                             Navigator.push(context,  MaterialPageRoute(
                                 builder: (context) =>
                                     MyRecipt(
                                         qrid: qrid, parkid: parkid)),

                             ),);
                        }
                        catch(e){print(e);}
                      }
                      else{
                        if (_formKey.currentState.validate()) {
                          Map <String,dynamic> data2={'txnid':txnid,'txtrefno':upino};data2.addAll(data);
                          await Firestore.instance
                              .collection('parkingDetails')
                              .document(parkid)
                              .collection('Slotsbooked')
                              .document(qrid)
                              .setData(data2);
                        Navigator.push(context,  MaterialPageRoute(
                              builder: (context) => MyRecipt(
                                  qrid: qrid, parkid: parkid)),);
                        }
                        else {
                          final snackbar = SnackBar(content: Text('Please Validate the required field'),);
                          ScaffoldMessenger.of(context).showSnackBar(snackbar);
                        }
                      }
                    },

                    child: Text('Confirm Boking',
                        style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold)),
                  ),
                ),
              ),

              /*Padding(
                padding: const EdgeInsets.all(15),
                child: Container(
                  height: 55,
                  width: double.infinity,
                  child: FlatButton(
                      color: Colors.blueAccent,
                      onPressed: () async {
                        //   final  CollectionReference slots=Firestore.instance.collection('parkingDetails').document(widget.docId).collection('Slotsavailable');
                        _handleRadioValueChange(_radioValue);
                        final CollectionReference book =
                            Firestore.instance.collection('parkingDetails');
                     //   var parkdata = data.values.toList();
                        String qrid = data['qrid'];

                        Map<String, dynamic> pay = {
                          'payment mode':
                              'Cash', //upadte according to payment mode
                        };
                        //karta data.add(pay);

                        print(data);

                        try {
                          book
                              .document(parkid)
                              .collection('Slotsbooked')
                              .document(qrid)
                              .setData(data)
                              .then((value) => Navigator.push(
                                  (context),
                                  MaterialPageRoute(
                                      builder: (context) => MyRecipt(
                                          qrid: qrid, parkid: parkid))));
                        } catch (e) {
                          print(e);
                        }
                      },
                      child: Text('Confirm Booking',
                          style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold)),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      )),
                ),
              )*/
            ])));
  }
}
