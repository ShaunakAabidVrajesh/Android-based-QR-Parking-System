import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'bookingpage.dart';
import 'createDrawerBodyItem.dart';
import 'bookinghistory.dart';
import 'cancelbookings.dart';
import 'navigationDrawer.dart';

class tabs extends StatefulWidget {
  String parkid;
  tabs({Key key, this.parkid}) : super(key: key);
  @override
  _tabsState createState() => _tabsState(this.parkid);
}

class _tabsState extends State<tabs> {
  var parkid;
  _tabsState(this.parkid);
  get parkingid =>parkid;

  @override
  Widget build(BuildContext) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
            bottom: TabBar(
              indicatorColor: Colors.white,
              tabs: [
                Tab(
                    icon: Icon(
                  Icons.flash_on_rounded,
                  semanticLabel: 'Current',
                )),
                Tab(
                    icon: Icon(
                  Icons.history,
                  semanticLabel: 'History',
                )),
                Tab(icon: Icon(Icons.cancel_rounded)),
              ],
            ),
            elevation: 6,
            title: Text('Bookings'),
            backgroundColor: Colors.blueAccent),
        drawer: navigationDrawer(),
        body: TabBarView(
          children: [
            new userbookingsdetails(parkid: parkingid),
            new bookinghistory(parkid: parkingid),
            new cancelled(parkid: parkingid),
          ],
        ),
      ),
    );
  }
}
