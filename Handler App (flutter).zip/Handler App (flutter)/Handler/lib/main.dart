import 'package:flutter/material.dart';
import 'package:qrcode/splashscreen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  //runApp(NewApp());

  runApp(MaterialApp(
    home: MyApp(),
    debugShowCheckedModeBanner: false,
  ));
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  @override
  Widget build(BuildContext context) {
    return SplashScreen();
  }
}
