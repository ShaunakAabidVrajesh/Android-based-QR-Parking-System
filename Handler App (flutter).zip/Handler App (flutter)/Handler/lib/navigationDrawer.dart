import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qrcode/homePage.dart';
import 'package:qrcode/login.dart';
import 'package:qrcode/prehomepage.dart';
import 'package:qrcode/scan.dart';
import 'package:qrcode/tabview.dart';

import 'contactdetails.dart';
import 'createDrawerBodyItem.dart';

class navigationDrawer extends StatelessWidget {
  var parkingid;
  navigationDrawer({Key key, this.parkingid}) : super(key: key);
  get parkid => parkingid;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          createDrawerHeader(),
          createDrawerBodyItem(
              icon: Icons.home,
              text: 'Home',
              onTap: () => Navigator.push((context),
                  MaterialPageRoute(builder: (context) => PreHomePage(parkingid: parkid,)))),
          createDrawerBodyItem(
              icon: Icons.bookmarks,
              text: 'Bookings',
              onTap: () => Navigator.push(
                  (context),
                  MaterialPageRoute(
                      builder: (context) => tabs(parkid: parkid)))),
          createDrawerBodyItem(
              icon: Icons.logout,
              text: 'Log Out',
              onTap: () async {
                await FirebaseAuth.instance.signOut();
                Navigator.of(context).pop();
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => login()));
              }),
          createDrawerBodyItem(
              icon: Icons.contact_phone,
              text: 'Contact Info',
              onTap: () {
                Navigator.of(context).pop();
                Navigator.push(
                    context, MaterialPageRoute(builder: (context) => contactdetails()));
              }),
          ListTile(
            title: Text('App version 1.0.0'),
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget createDrawerHeader() {
    return DrawerHeader(
        margin: EdgeInsets.zero,
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: Colors.blueAccent,
           image: DecorationImage(
           fit: BoxFit.fill,
           image: AssetImage('assets/images/qr-code.png'))),

        child: Stack(children: <Widget>[
          Positioned(
              bottom: 12.0,
              left: 16.0,
              child: Text("Welcome Handler",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.0,
                      fontWeight: FontWeight.w500))),
        ]));
  }
}
