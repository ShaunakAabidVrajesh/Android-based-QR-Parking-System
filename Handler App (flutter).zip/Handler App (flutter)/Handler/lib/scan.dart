import 'package:barcode_scan/barcode_scan.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:qrcode/homePage.dart';
import 'package:qrcode/receipt.dart';

class ScanPage extends StatefulWidget {
  var parkid;
  ScanPage({Key key, this.parkid}) : super(key: key);
  @override
  _ScanPageState createState() => _ScanPageState(this.parkid);
}

class _ScanPageState extends State<ScanPage> {
  String qrCodeResult = "Not Scanned";
  var parkid;
  _ScanPageState(this.parkid);

  get codeScanner => null;
  @override
  Widget build(BuildContext context) {
    Map data;



    return Scaffold(
      appBar: AppBar(
        title: Text("Scanner"),
        centerTitle: true,
        backgroundColor: Colors.blueAccent,
        elevation: 10,
      ),
      body: Container(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              "Result",
              style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Text(
              qrCodeResult,
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 20.0,
            ),
            FlatButton(
              padding: EdgeInsets.all(15.0),
              onPressed: () async {
                String codeSanner = await BarcodeScanner.scan(); //qrcode scnner
                setState(() {
                  qrCodeResult = codeSanner;
                });
              },
              child: Text(
                "Open Scanner",
                style:
                    TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
              ),
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.blue, width: 3.0),
                  borderRadius: BorderRadius.circular(20.0)),
            ),
            FlatButton(
              padding: EdgeInsets.all(15.0),
              onPressed: () async {
                String qrid = (qrCodeResult).toString();
                String userid;
                print(parkid);
                await Firestore.instance
                    .collection('parkingDetails')
                    .document(parkid)
                    .collection('Slotsbooked')
                    .document(qrid)
                    .get()
                    .then((value) => {
                          if (value.exists)
                            {
                              print(userid),
                              userid = value.data['userid'],
                              print(userid),
                              print(qrid),
                              Navigator.push(
                                  (context),
                                  MaterialPageRoute(
                                      builder: (context) => MyRecipt(
                                          qrid: qrid,
                                          userid: userid,
                                          parkid: parkid))),
                            }
                          else{
                            print(value),}
                        });

                // book.document(widget.docId).collection('Slotsbooked').document(qrid).setData(data).then((value) =>
              },
              child: Text(
                "Check Status",
                style:
                    TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
              ),
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.blue, width: 3.0),
                  borderRadius: BorderRadius.circular(20.0)),
            )
          ],
        ),
      ),
    );
  }

//its quite simple as that you can use try and catch staatements too for platform exception
}
