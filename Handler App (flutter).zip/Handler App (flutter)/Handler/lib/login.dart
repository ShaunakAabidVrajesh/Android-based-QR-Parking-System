import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:country_code_picker/country_code_picker.dart';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:qrcode/homePage.dart';
import 'package:qrcode/prehomepage.dart';

// ignore: camel_case_types
class login extends StatefulWidget {
  @override
  _loginState createState() => _loginState();
}

// ignore: camel_case_types
class _loginState extends State<login> {
  String phoneNumber, parkingname;
  String countryCode = "+91";
  bool secure = true;
  FocusNode no1 = FocusNode();
  FocusNode no2 = FocusNode();
  final _formKey = GlobalKey<FormState>();
  bool isloading = false;
  final skey = GlobalKey<ScaffoldState>();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    //  decrypt();
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
          key: skey,
          appBar: AppBar(

            automaticallyImplyLeading: false,
            title: Text(
              "Login Details",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            backgroundColor: Colors.blueAccent,
            elevation: 10,
            centerTitle: true,
            textTheme: Theme.of(context).textTheme,
          ),
          body: WillPopScope(
            onWillPop: () async {
              return showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text('Are you sure?'),
                        content: Text("Do you want to Exit App"),
                        actions: [
                          new TextButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: Text('No')),
                          new TextButton(
                              onPressed: () {
                                SystemChannels.platform
                                    .invokeMethod('SystemNavigator.pop');
                                Navigator.of(context).pop(true);
                              },
                              child: Text('Yes')),
                        ],
                      );
                    },
                  ) ??
                  false;
            },
            child: SafeArea(
              child: isloading
                  ? Center(
                      child: CircularProgressIndicator(
                      valueColor:
                          new AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                    ))
                  : SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(height: 10),
                          SizedBox(
                            height: MediaQuery.of(context).size.height * 0.20, //130,
                            child: Image.asset('assets/images/qr-code.png'),
                          ),
                          Text(
                            'Handler',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 25),
                          ),
                          SizedBox(height: 20),
                          Form(
                            key: _formKey,
                            child: Column(
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Container(
                                    height: 65,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: 15, right: 15, top: 4),
                                      child: TextFormField(
                                        decoration: InputDecoration(
                                          border: InputBorder.none,
                                          counterText: '',
                                          hintText: 'phonenumber',
                                          fillColor: Colors.white,
                                          errorStyle: TextStyle(height: 0.3),
                                          prefixIcon: CountryCodePicker(
                                            onChanged: (e) =>
                                                print(e.toLongString()),
                                            initialSelection: 'IN',
                                            enabled: false,
                                            showFlag: true,
                                            favorite: ['+91', 'IN'],
                                            hideSearch: true,
                                          ),
                                        ),
                                        maxLength: 10,
                                        keyboardType: TextInputType.number,
                                        inputFormatters: [
                                          FilteringTextInputFormatter.digitsOnly
                                        ],
                                        focusNode: no1,
                                        validator: (value) {
                                          if (value.isEmpty) {
                                            return 'Mobile Number must not be empty';
                                          } else if (value.length != 10) {
                                            return 'Mobile Number must be 10 digit';
                                          } else {
                                            setState(() {
                                              phoneNumber = '+91' + ' ' + value;
                                            });
                                            return null;
                                            //to nAVIAGTE AFTER VERIFYING
                                          }
                                        },
                                        onChanged: (n) {
                                          if (n.length == 10) {
                                            setState(() {
                                              phoneNumber = '+91' + ' ' + n;
                                            });
                                            FocusScope.of(context)
                                                .requestFocus(no2);
                                            //fieldFocusChange(context,n1,n2);
                                          }
                                        },
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Container(
                                    height: 60,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.only(
                                          left: 15, right: 15, top: 4),
                                      child: TextFormField(
                                          obscureText: secure,
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            errorStyle: TextStyle(height: 0.3),
                                            fillColor: Colors.white,
                                            prefixIcon: Icon(Icons.assignment),
                                            hintText: 'parking site name',
                                          ),
                                          focusNode: no2,
                                          onChanged: (n) {
                                            if (n.length != 0) {
                                              setState(() {
                                                parkingname = n;
                                              });
                                              //fieldFocusChange(context,n1,n2);
                                            } else if (n.isEmpty) {
                                              FocusScope.of(context)
                                                  .requestFocus(no1);
                                            }
                                          },
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              FocusScope.of(context)
                                                  .requestFocus(no2);

                                              return 'Cannot be Null';
                                            } else
                                              // ignore: missing_return, missing_return
                                              parkingname = value;
                                            return null;
                                            //to nAVIAGTE AFTER VERIFYING
                                          }),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                    height: MediaQuery.of(context).size.height *
                                        0.2),
                                Padding(
                                  padding: const EdgeInsets.all(15),
                                  child: Container(
                                    height:60,
                                    width: double.infinity ,
                                    child: ElevatedButton(

                                      onPressed: () async {
                                        print(phoneNumber);
                                        print(parkingname);
                                        if (_formKey.currentState.validate()) {
                                          parkingdeatils(
                                              phoneNumber, parkingname);
                                        }
                                        else {
                                          final snackbar = SnackBar(
                                            content:
                                                Text('Validated the feilds'),
                                          );
                                          skey.currentState
                                              .showSnackBar(snackbar);
                                        }
                                      },
                                        style: ElevatedButton.styleFrom(
                                            primary: Colors.blueAccent,
                                            elevation: 10,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                              BorderRadius.circular(10.0),
                                            ), ),
                                      child: Text(
                                        'LOGIN',
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontWeight: FontWeight.bold),
                                        //shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(10.0),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
            ),
          )),
    );
  }

  parkingdeatils(String phoneNumber, String parkingname) {
    Firestore.instance
        .collection('parkingDetails')
        .document(parkingname)
        .collection('Handler')
        .where('Contactnumber', isEqualTo: phoneNumber)
        .getDocuments()
        .then(
          (snapshot) => {
            if (snapshot.documents.isNotEmpty)
              {
                setState(() {
                  isloading = true;
                }),
                Navigator.push(
                    (context),
                    MaterialPageRoute(
                        builder: (context) => PreHomePage(
                            parkingid: parkingname, phno: phoneNumber))),
              }
            else
              {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                  content: new Text('Incorrect Details'),
                  backgroundColor: Colors.blueAccent,
                  behavior: SnackBarBehavior.floating,
                  elevation: 5,
                )),
              }
          },
        );
  }
}
