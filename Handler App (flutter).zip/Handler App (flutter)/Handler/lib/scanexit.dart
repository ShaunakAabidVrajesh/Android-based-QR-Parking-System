
import 'package:barcode_scan/barcode_scan.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:qrcode/prehomepage.dart';

class ScanexitPage extends StatefulWidget {
  var parkid;
  ScanexitPage({Key key, this.parkid}) : super(key: key);
  @override
  _ScanexitPageState createState() => _ScanexitPageState(this.parkid);
}

class _ScanexitPageState extends State<ScanexitPage> {
  String qrCodeResult = "Not Scanned";
  var parkid;
  _ScanexitPageState(this.parkid);

  get codeScanner => null;
  var checkedintime;
  double checktime;
  TimeOfDay converttime(String time) {
    int h = 0;
    if (time.endsWith('PM'))
      h = 12;
    else if (time.endsWith('AM')) h = 0;
    time = time.split(' ')[0];
    return TimeOfDay(
        hour: h + int.parse(time.split(":")[0]) % 24,
        minute: int.parse(time.split(":")[1].split(" ")[0]) % 60);
  }

  double ch(TimeOfDay c) => c.hour + c.minute / 60.0;
  @override

  @override
  Widget build(BuildContext context) {


    return new Scaffold(
      appBar: AppBar(
        title: Text("Scanner"),
        centerTitle: true,
      ),
      body:new Container(
        padding: EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text(
              "Result",
              style: TextStyle(fontSize: 25.0, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            Text(
              qrCodeResult,
              style: TextStyle(
                fontSize: 20.0,
              ),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 20.0,
            ),
            FlatButton(
              padding: EdgeInsets.all(15.0),
              onPressed: () async {
                String codeSanner = await BarcodeScanner.scan(); //qrcode scnner
                setState(() {
                  qrCodeResult = codeSanner;
                });
              },
              child: Text(
                "Open Scanner",
                style:
                    TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
              ),
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.blue, width: 3.0),
                  borderRadius: BorderRadius.circular(20.0)),
            ),
            FlatButton(
              padding: EdgeInsets.all(15.0),
              onPressed: () async {
                String qrid = (qrCodeResult).toString();
                check(qrid);
                String userid;
                print(parkid);

              },
              child: Text(
                "Exited",
                style:
                    TextStyle(color: Colors.blue, fontWeight: FontWeight.bold),
              ),
              shape: RoundedRectangleBorder(
                  side: BorderSide(color: Colors.blue, width: 3.0),
                  borderRadius: BorderRadius.circular(20.0)),
            )
          ],
        ),
      ),
    );
  }
  check(String qr) async{
    var dates = DateFormat('hh:mm a').format(DateTime.now());
    print(qr);print(dates);
print(qr);    await Firestore.instance
        .collection('parkingDetails')
        .document(parkid)
        .collection('Slotsbooked')
        .document(qr)
        .get()
        .then(
          (value) {
        if (value.exists) {
          var userid=value.data['userid'];
          print(userid);
          var initialtime = DateFormat('hh:mm a').format(DateTime.now());
          double currentime = ch(converttime(initialtime));
          print(currentime);
          checkedintime = value.data['checkin'];
          print(checkedintime);
          checktime = ch(converttime(checkedintime)) + 1.10;
          print(checktime);
          if(userid!=null) {

              if (currentime > checktime) {
                var extrafee = ((currentime - checktime)*60).toStringAsFixed(2);
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text(
                          'Time Exceeded',
                          style:
                          TextStyle(fontWeight: FontWeight.bold),
                        ),
                        content:  Text(
                            'Please pay extra fee for exceeding time $extrafee minutes'),
                        actions: <Widget>[
                          ElevatedButton(
                              child: Text('Ok'),
                              onPressed: () async{
                                Navigator.of(context).pop();
                                Firestore.instance
                                    .collection('users')
                                    .document(userid)
                                    .collection('Bookings')
                                    .document(qr)
                                    .updateData({'checkout': dates});
                               await Firestore.instance
                                    .collection('parkingDetails')
                                    .document(parkid)
                                    .collection('Slotsbooked')
                                    .document(qr)
                                    .updateData({'checkout': dates}).then((value) =>Navigator.pop(context),
                                   );
                                Navigator.push(
                                    (context),
                                    MaterialPageRoute(
                                        builder: (context) =>
                                            PreHomePage(parkingid: parkid)));
                              }),
                        ],
                      );
                    }); //showdialll



              } //this one for 2nd if
              else {
                Firestore.instance
                    .collection('users')
                    .document(userid)
                    .collection('Bookings')
                    .document(qr)
                    .updateData({'checkout': dates});
                 Firestore.instance
                    .collection('parkingDetails')
                    .document(parkid)
                    .collection('Slotsbooked')
                    .document(qr)
                    .updateData({'checkout': dates}).then((value) =>Navigator.pop(context),
                );
                Navigator.push(
                    (context),
                    MaterialPageRoute(
                        builder: (context) =>
                            PreHomePage(parkingid: parkid)));
              }

          }
          else{
            Firestore.instance
                .collection('parkingDetails')
                .document(parkid)
                .collection('Slotsbooked')
                .document(qr)
                .updateData({'checkout': dates});
            Navigator.push(
                (context),
                MaterialPageRoute(
                    builder: (context) =>
                        PreHomePage(parkingid: parkid)));

          }
        }

          else{
            final snackbar = SnackBar(
              content: Text(
                  'No records'),
            );
            ScaffoldMessenger.of(context).showSnackBar(snackbar);
          }

    });

  }
}

//its quite simple as that you can use try and catch staatements too for platform exception

