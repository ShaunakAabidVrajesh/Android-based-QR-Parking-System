import 'dart:core';
import 'package:intl/intl.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:qrcode/homePage.dart';
import 'package:qrcode/prehomepage.dart';

class MyRecipt extends StatefulWidget {
  String qrid, parkid, userid;
  MyRecipt({Key key, this.qrid, this.parkid, this.userid}) : super(key: key);
  @override
  State createState() => _MyReciptState(this.qrid, this.parkid, this.userid);
}

class _MyReciptState extends State<MyRecipt> {
  String phno;
  var qrid, parkid, userid;

  _MyReciptState(this.qrid, this.parkid, this.userid);

  String get Qrid => qrid;
  String get Docid => parkid;
  String get Userid => userid;

  final FirebaseAuth auth = FirebaseAuth.instance;
  var username, slotno, booktime, reservetime, address;
  //String parkid;
  @override
  void initState() {
    // TODO: implement initStat
    //getcurrentuserid();
    Firebase();
    //
    super.initState();
  }

  Firebase() async {
    //Firestore firestore=Firestore.instance;
    //   print(phonenumber+ " "+Userid);

    try {
      DocumentReference db = Firestore.instance
          .collection('parkingDetails')
          .document(Docid)
          .collection('Slotsbooked')
          .document(Qrid);
      db.get().then((value) => {
            if (value.exists)
              {
                setState(() {
                  username = value.data['username'];
                  slotno = value.data['slotno'];
                  booktime = value.data['booktime'];
                  reservetime = value.data['reserve'];
                  address = value.data['address'];
                }),
                print(Docid),
                print(username),
                print(Userid),
              }
            else
              {
                AlertDialog(
                  title: Text('$Qrid'),
                  content: const Text('No data found'),
                  actions: <Widget>[
                    ElevatedButton(
                        child: Text('Ok'),
                        onPressed: () {
                          Navigator.of(context).pop();
                        })
                  ],
                )
              }
          });
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async{
        return false;
      },
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(
            "Booking Details",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          backgroundColor: Colors.blueAccent,
          elevation: 0,
          centerTitle: true,
          textTheme: Theme.of(context).textTheme,
        ),
        //drawer: navigationDrawer(),
        body: SafeArea(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(
                    height: 30,
                  ),
                  Center(
                    child: QrImage(
                      data: Qrid,
                      version: QrVersions.auto,
                      size: 200.0,
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 18.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'User-Name',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Text(
                              '$username',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 32),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Parking Slot',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Text(
                              '$slotno',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 32),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 18.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'From',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Text(
                              '$booktime',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 20),
                            ),
                          ],
                        ),
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'To',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13),
                            ),
                            SizedBox(
                              height: 8,
                            ),
                            Text(
                              '$reservetime',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 20),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 25,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      'Full Address',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[400],
                          fontSize: 13,
                          letterSpacing: 0.2),
                    ),
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      '$address',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.grey[900],
                          fontSize: 16.4,
                          letterSpacing: 0.2),
                    ),
                  ),
                  SizedBox(
                    height: 50,
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15),
                    child: Container(
                      height: 60,
                      width: MediaQuery.of(context).size.width * 6,
                      child: RaisedButton(
                        elevation: 6,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(10.0)),
                        onPressed: () async {
                          String dates = DateFormat('hh:mm a').format(DateTime.now()).toString();
                          if (userid != null) {
                            await Firestore.instance
                                .collection('users')
                                .document(Userid)
                                .collection('Bookings')
                                .document(Qrid)
                                .updateData(
                                { 'parked': 'Yes',
                                  'checkedin':dates
                                });
                            await Firestore.instance
                                .collection('parkingDetails')
                                .document(Docid)
                                .collection('Slotsbooked')
                                .document(Qrid)
                                .updateData(
                                {
                                  "parked":'Yes',
                                  "checkin":dates});

                            Navigator.push(
                                (context),
                                MaterialPageRoute(
                                    builder: (context) =>
                                        PreHomePage(parkingid: Docid)));
                          } else {
                            // await Firestore.instance
                            //     .collection('parkingDetails')
                            //     .document(Docid)
                            //     .collection('Slotsbooked')
                            //     .document(Qrid)
                            //     .updateData({'parked': 'Yes'});

                            Navigator.push(
                                (context),
                                MaterialPageRoute(
                                    builder: (context) =>
                                        PreHomePage(parkingid: Docid)));
                          }
                        },
                        color: Colors.blueAccent,
                        padding: EdgeInsets.symmetric(vertical: 14),
                        child: Text(
                          'Verify & Continue',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              wordSpacing: 2,
                              letterSpacing: 0.4),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
