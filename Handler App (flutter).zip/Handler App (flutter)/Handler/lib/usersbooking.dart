import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:intl/intl.dart';
import 'dart:core';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class CustomCard extends StatelessWidget {
  CustomCard({
    @required this.name,
    this.booktime,
    this.reserve,
    this.slotno,
    this.address,
    this.date,
    this.qrid,
    this.booking,
    this.parked,
    this.vehicleno,
    this.userid,
    this.phno,
  });

  final name, userid;
  final slotno,
      address,
      booktime,
      reserve,
      qrid,
      booking,
      parked,
      vehicleno,
      date;
  final phno;
  //DateTime time=DateFormat.yMMMd().add_jm().format(date) as DateTime;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: GestureDetector(
        onTap: () {
          showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: new Center(
                      child: Text('Parking Details',
                          style: TextStyle(color: Colors.blueAccent))),
                  content: new Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        QrImage(
                          data: qrid,
                          version: QrVersions.auto,
                          size: 200.0,
                        ),
                        //Text('Parking ID :  $qrid' ,style: TextStyle(fontSize: 13),),
                        SizedBox(
                          height: 15,
                        ), //id
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'Parking ID:',
                              style: TextStyle(
                                //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15,
                              ),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            SingleChildScrollView(
                              scrollDirection: Axis.horizontal,
                              child: Container(
                                width: 145,
                                child: Text(
                                  '$qrid',
                                  style: TextStyle(
                                      fontWeight: FontWeight.w700,
                                      fontSize: 15),
                                ),
                              ),
                            ),
                          ],
                        ), //parking id
                        SizedBox(
                          height: 12,
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'UserName:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$name',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Colors.blueAccent,
                              ),
                            ),
                          ],
                        ), //name
                        SizedBox(
                          height: 12,
                        ), //time

                        //name
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'Booking Status:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$booking',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ), //book status
                        SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'MobileNo:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$phno',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ), //booktime
                        SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            //  SizedBox(width: 67,),
                            Text(
                              'Booked from:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$booktime',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            //    SizedBox(width: 67,),
                            Text(
                              'To:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$reserve',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ), //reserve time
                        SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'Slot No:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$slotno',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ), //slotno
                        SizedBox(
                          height: 12,
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'Parked:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$parked',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15,
                                color: Colors.green,
                              ),
                            ),
                          ],
                        ), //parked status
                        SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'Vehicle No:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$vehicleno',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ), //vehicle no
                        SizedBox(
                          height: 12,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              'Date:',
                              style: TextStyle(
                                  //   fontWeight: FontWeight.w500,
                                  color: Colors.black45,
                                  fontSize: 15),
                            ),
                            SizedBox(
                              width: 5,
                            ),
                            Text(
                              '$date',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700, fontSize: 15),
                            ),
                          ],
                        ), //date
                      ],
                    ),
                  ),
                  actions: <Widget>[
                    // usually buttons at the bottom of the dialog
                    new ElevatedButton(
                      child: new Text('Cancel Booking'),
                      onPressed: () async {
                        try {
                          await Firestore.instance
                              .collection("users")
                              .document(userid)
                              .collection("Bookings")
                              .document(qrid)
                              .updateData({'booking': 'Cancelled'}).then(
                            (value1) => Firestore.instance
                                .collection("parkingDetails")
                                .document('shonkpark')
                                .collection('Slotsbooked')
                                .document(qrid)
                                .updateData({
                              'bookingstatus': 'Cancelled'
                            }).then((value) => Navigator.pop(context)),
                          );
                        } catch (e) {
                          print(e);
                        }
                      },
                    ),
                    new TextButton(
                      child: new Text("Close"),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                  ],
                );

                /*  return AlertDialog(
                        title: Center(child: Text('Parking ID')),
                        content: Center(
                            child: Column(
                                children: [
                                    QrImage(
                                        data: qrid,
                                        version: QrVersions.auto,
                                        size: 200.0,
                                    ),
                                    Text('Parking ID: $qrid' ,style: TextStyle(fontSize: 11,),),
                                ],
                            ),
                        ),
                        actions: [
                            ElevatedButton(
                                style:ElevatedButton.styleFrom(primary: Colors.blueAccent),
                                onPressed: (){
                                    Navigator.pop(context);
                                },
                                child: Text("CANCEL"),
                            ),
                        ],
                        );*/
              });
        },
        child: Container(
          width: 175,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(15)),
            // border: Border.all(color: Colors.blueAccent),
            boxShadow: [
              BoxShadow(
                color: Colors.black12,
                offset: const Offset(5.0, 5.0),
                blurRadius: 6.0,
                spreadRadius: 5.0,
              ),
            ],
          ),
          //  margin: EdgeInsets.symmetric(vertical: 5),
          padding: const EdgeInsets.all(15),
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  // SizedBox(height: 5)
                  Text(
                    name.toUpperCase(),
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.blueAccent,
                        fontSize: 15),
                  ),
                  //    SizedBox(height: 2),
                  Text(
                    '$booktime',
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                        fontSize: 13),
                  ),
                  Text(
                    '$reserve',
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                        fontSize: 13),
                  ),
                  Text(
                    slotno,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.green,
                        fontSize: 15),
                  ),

                  Text(
                    date,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                        fontSize: 10),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
