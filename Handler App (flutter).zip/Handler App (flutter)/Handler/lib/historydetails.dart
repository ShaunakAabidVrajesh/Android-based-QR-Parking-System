import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';

import 'dart:core';
import 'package:cloud_firestore/cloud_firestore.dart';

class CustomCard extends StatelessWidget {
  CustomCard({ this.username, this.booktime,this.reserve,this.slotno,
    this.useraddress,this.date,this.qrid,this.booking,this.parked,this.vehicleno,
    this.fee,this.phno,this.status,this.txnid,this.txtrefno,this.userid,this.checkedin,this.checkout,
  this.parkname,this.createdon});

  final username,checkedin,checkout,parkname;
  final slotno,useraddress,booktime,reserve,qrid,booking,parked,vehicleno,fee,userid,status,txnid,txtrefno,phno,createdon;
  final date;bool check=false;

  //DateTime time=DateFormat.yMMMd().add_jm().format(date) as DateTime;
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: GestureDetector(
        onTap: (){
          showDialog(context: context, builder: (BuildContext context){

            return AlertDialog(
              title: new  Center(child: Text('Booking History',style:TextStyle(color:Colors.black87, ))),
              content: SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child:new  Center(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [

                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('-------  ',style: TextStyle(color: Colors.black12),),
                          Text(
                            'Parking Details',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.blueAccent,
                                fontSize: 15
                            ),
                          ),
                          Text('  -------',style: TextStyle(color: Colors.black12),),

                        ],
                      ),//parking tag
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Parking ID:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                              color: Colors.black45,
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(width: 5,),
                          SingleChildScrollView(
                            scrollDirection: Axis.horizontal,
                            child: Container(
                              width: 145,
                              child: Text(
                                '$qrid',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),  //parking id
                      SizedBox(height: 12,),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'User-Name:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$username',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                              color:Colors.blueAccent,
                            ),
                          ),
                        ],
                      ),//name
                      SizedBox(height: 12,),
                      //time
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Address:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$useraddress',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,
                              color:Colors.black,
                            ),
                          ),
                        ],
                      ),//address
                      SizedBox(height: 12,),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Booking Status:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$booking',
                            style: 'Confirm'==booking?TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,color: Colors.green,
                            ):TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,color: Colors.red,
                            ),
                          ),
                        ],
                      ),//book status
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Reserved from :',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$booktime',
                            style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15
                            ),
                          ),
                          Text('-'),
                          Text(
                            '$reserve',
                            style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15
                            ),
                          ),
                        ],
                      ),//booktime
                      SizedBox(height: 12,),

                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Slot No:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$slotno',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,color: Colors.indigo,
                            ),
                          ),
                        ],
                      ),//slotno


                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Parked:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$parked',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,color: Colors.green,
                            ),
                          ),
                        ],
                      ),//parked status
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Vehicle No:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$vehicleno',
                            style: TextStyle(
                                fontWeight: FontWeight.w700,
                                fontSize: 15
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Checkout-time:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          checkedin=='No'? Text(
                            'Not Checkedin',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 15
                            ),
                          ):Text(
                            '$checkedin',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 15
                            ),
                          ),
                        ],
                      ),//vehicle no
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Checkin-time:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          checkout=='No'?Text(
                            'Not Checkout',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 15
                            ),
                          ):Text(
                            '$checkout',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 15
                            ),
                          ),
                        ],
                      ),//vehicle no
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Date:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$date',
                            style: TextStyle(
                                fontWeight: FontWeight.w500,
                                fontSize: 15
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12,),
                      //date
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text('-------  ',style: TextStyle(color: Colors.black12),),
                          Text(
                            'Payment Details',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.blueAccent,
                                fontSize: 15
                            ),
                          ),
                          Text('  -------',style: TextStyle(color: Colors.black12),),

                        ],
                      ),
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start ,
                        children: <Widget>[
                          Text(
                            'Transcation Status:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                                color: Colors.black45,
                                fontSize: 15
                            ),
                          ),
                          SizedBox(width: 5,),
                          Text(
                            '$status',
                            style: TextStyle(
                              fontWeight: FontWeight.w700,
                              fontSize: 15,color:Colors.green,
                            ),
                          ),
                        ],
                      ),//vehicle no
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Transcation ID:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                              color: Colors.black45,
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(width: 5,),
                          Flexible(
                            child: Container(

                              width: 125,
                              child: Text(
                                '$txnid',
                                style: TextStyle(
                                  //  fontWeight: FontWeight.w700,
                                    fontSize: 12
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 12,),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Text(
                            'Transcation no:',
                            style: TextStyle(
                              //   fontWeight: FontWeight.w500,
                              color: Colors.black45,
                              fontSize: 15,
                            ),
                          ),
                          SizedBox(width: 5,),
                          Flexible(
                            child: Container(
                              //width: 125,
                              child: Text(
                                '$txtrefno',
                                style: TextStyle(
                                    fontWeight: FontWeight.w700,
                                    fontSize: 12
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      //vehicle no

                    ],
                  ),
                ),
              ),
              actions: <Widget>[
                // usually buttons at the bottom of the dialog
                new ElevatedButton(
                  child: new Text('Delete'),
                  onPressed: () async{
                 
                       Firestore.instance.collection("parkingDetails").document(parkname).
                       collection('Slotsbooked').
                       document(qrid).delete().then((value1) =>Navigator.pop(context));

                  },
                ),
                new TextButton(
                  child: new Text("Close"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },

                )
              ],
            );

          });

        },
        child: Container(
          width: 175,
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(15)),
            // border: Border.all(color: Colors.blueAccent),
            boxShadow: [
              BoxShadow(
                color: Colors.black12 ,
                offset: const Offset(5.0,5.0 ),
                blurRadius: 6.0,
                spreadRadius: 5.0,
              ),
            ],
          ),
          //  margin: EdgeInsets.symmetric(vertical: 5),
          padding:const EdgeInsets.all(15),
          child: Stack(
            alignment: Alignment.center,
            children: <Widget>[
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: <Widget>[

                  // SizedBox(height: 5)
                  Text(
                    username,
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        color: Colors.blueAccent,
                        fontSize: 15
                    ),),
                  Text(
                    '$useraddress',
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.black45,
                        fontSize: 12
                    ),),
                  SizedBox(height: 2),
                  Text(
                    vehicleno,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.black87,
                        fontSize: 13
                    ),),
                  // SizedBox(height: 2),
                  Text(
                    booking,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: booking=='Confirm'?Colors.green:Colors.red,
                        fontSize: 15
                    ),),

                  Text(
                    date,
                    style: TextStyle(
                        fontWeight: FontWeight.w500,
                        color: Colors.black,
                        fontSize: 10
                    ),),

                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}