import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';
import 'package:qrcode/payment.dart';

import 'dart:math';
import 'dart:async';

import 'navigationDrawer.dart';

// ignore: must_be_immutable
class bookingdetails extends StatefulWidget {
  var parkname;

  bookingdetails({Key key, this.parkname}) : super(key: key);
  @override
  _bookingdetailsState createState() => _bookingdetailsState(this.parkname);
}

class _bookingdetailsState extends State<bookingdetails> {
  // var phonenumber;

  bool isloading = false;
  var parkname;
  var username, useraddress;
  //var phonenumber;
  bool isLoading = false;
  String stime, brtime;
  double bstime, x1, x2;

  _bookingdetailsState(this.parkname);

  final skey = GlobalKey<ScaffoldState>();
  String vno;
  TextEditingController _controller = TextEditingController();
  TextEditingController controller = TextEditingController();
  TextEditingController dcontroller = TextEditingController();
  final _formKey = GlobalKey<FormState>();
  final FirebaseAuth auth = FirebaseAuth.instance;
  String get park => parkname;
  var pname;
  String slots;
  var workingday;
  var endday;
  var upino;
  var starttime, address;
  var endtime;
  var week;
  var dates = DateFormat.yMMMd().format(DateTime.now());
  var slottime;
  var reservedtime, phno;
  TimeOfDay initialtime = TimeOfDay.now();

  double booktime, opentime, booktill, closetime;
  //converting time in double
  TimeOfDay converttime(String time) {
    int h = 0;
    if (time.endsWith('PM'))
      h = 12;
    else if (time.endsWith('AM')) h = 0;
    time = time.split(' ')[0];
    return TimeOfDay(
        hour: h + int.parse(time.split(":")[0]) % 24,
        minute: int.parse(time.split(":")[1].split(" ")[0]) % 60);
  }

  double ch(TimeOfDay c) => c.hour + c.minute / 60.0;
var userno;
  var key;
  @override
  void initState() {
    // TODO: implement initStat
    isloading = false;
    // getcurrentuserid();
    Firebase();
    //
    super.initState();
  }

  Firebase() async {
    int slot, randamno;
    Random random;
    String slotno;
    String dates = DateFormat.yMMMd().format(DateTime.now()).toString();
    try {
      DocumentReference db =
          Firestore.instance.collection('parkingDetails').document(park);
      db.get().then((value) => {
            if (value.exists)
              {
                setState(() {
                  pname = value.data['name'];
                  slots = value.data['slots'];
                  workingday = value.data['Workingday'];
                  endday = value.data['Endday'];
                  starttime = value.data['Starttime'];
                  endtime = value.data['Endtime'];
                  week = value.data['Week'];
                  address = value.data['address'];
                  phno = value.data['phno'];
                }),
                print(slots),
                print(phno),
                print(pname),
                slot = int.parse('$slots'),
                random = new Random(),
                randamno = random.nextInt(slot),
                slotno = 'S' + randamno.toString(),
                print(slotno),
                slotfreechecking(slotno, dates),
              }
            else
              {
                skey.currentState
                    .showSnackBar(SnackBar(content: Text('$parkname '+' '+park))),
              }
          });
    } catch (e) {
      print(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return new  SafeArea(
      child: new Scaffold(
          key: skey,
          appBar: AppBar(
            leading: IconButton(
              icon: Icon(Icons.arrow_back_ios),
              color: Colors.white,
              onPressed: () {
                Navigator.pop(context);
              },
            ),
            title: Text(
              "Booking Details",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            backgroundColor: Colors.blueAccent,
            elevation: 10,
            centerTitle: true,
            textTheme: Theme.of(context).textTheme,
          ),
          drawer: navigationDrawer(),
          body: isloading
              ? Center(
                  child: CircularProgressIndicator(
                  valueColor:
                      new AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                ))
              :new  SingleChildScrollView(
                  scrollDirection: Axis.vertical,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: <Widget>[
                      Form(
                        key: _formKey,
                        child: Column(
                          children: <Widget>[
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 60,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    autofocus: true,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      fillColor: Colors.white,
                                      prefixIcon: Icon(
                                        Icons.account_circle,
                                        color: Colors.blueAccent,
                                      ),
                                      enabled: false,
                                      hintText: pname,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(15.0),
                              child: Container(
                                height: 60, //60,
                                decoration: BoxDecoration(

                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.only(
                                      left: 15, right: 15, top: 5),
                                  child: TextFormField(
                                      autofocus: true,
                                      decoration: InputDecoration(
                                        counterText: '',
                                        border: InputBorder.none,
                                        errorStyle: TextStyle(height: 0.3),
                                        fillColor: Colors.white,

                                        prefixIcon: CountryCodePicker(
                                          onChanged: (e) =>
                                              print(e.toLongString()),
                                          initialSelection: 'IN',
                                          enabled: false,
                                          showFlag: true,
                                          favorite: ['+91', 'IN'],
                                          hideSearch: true,
                                        ),
                                      ),
                                      maxLength: 10,
                                      controller: controller,
                                      keyboardType: TextInputType.number,
                                      inputFormatters: [
                                        FilteringTextInputFormatter.digitsOnly
                                      ],
                                      validator: (value) {
                                        if (value.isEmpty) {
                                          return 'Mobile Number must not be empty';
                                        } else if (value.length != 10) {
                                          _controller.clear();
                                          return 'Mobile Number must be 10 digit';
                                        } else {
                                          setState(() {
                                             userno='+91'+value;
                                          });
                                          //to nAVIAGTE AFTER VERIFYING
                                        }
                                      }),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 60,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      fillColor: Colors.white,
                                      prefixIcon: Icon(
                                        Icons.account_circle,
                                      ),
                                      //  suffixIcon: Icon(Icons.check_circle_outline,color: Colors.black26,),
                                      counterText: '',
                                      hintText: 'Name',
                                      errorStyle: TextStyle(height: 0.3),
                                    ),
                                    maxLength: 20,
                                    autofocus: true,
                                    keyboardType: TextInputType.text,
                                    validator: (value) {
                                      if (value.isEmpty) {
                                        return 'Please enter Name';
                                      } else {
                                        setState(() {
                                          username = value;
                                        });
                                        return null;
                                      }
                                      //to nAVIAGTE AFTER VERIFYING
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 60,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: _controller,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      fillColor: Colors.blueAccent,
                                      prefixIcon: Icon(
                                        Icons.directions_car,
                                      ),
                                      hintText: 'Vehicle Number(GA 04 W 4467)',
                                      errorStyle: TextStyle(height: 0.3),
                                    ),
                                    textCapitalization:
                                        TextCapitalization.characters,
                                    validator: (value) {
                                      Pattern pattern =
                                          r'^[A-Z]{2}[ -][0-9]{1,2}(?: [A-Z])?(?: [A-Z]*)? [0-9]{4}$';
                                      RegExp regex = new RegExp(pattern);
                                      if (value.isEmpty) {
                                        return 'Required';
                                      } else {
                                        if (!regex.hasMatch(value)) {
                                          _controller.clear();
                                          return 'Enter valid format';
                                        } else {
                                          setState(() {
                                            vno = value;
                                          });
                                          return null;
                                        }
                                      }
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 60,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      fillColor: Colors.white,
                                      prefixIcon: Icon(
                                        Icons.account_circle,
                                      ),
                                      //  suffixIcon: Icon(Icons.check_circle_outline,color: Colors.black26,),
                                      counterText: '',
                                      hintText: 'Address',
                                      errorStyle: TextStyle(height: 0.3),
                                    ),
                                    maxLength: 20,
                                    keyboardType: TextInputType.text,
                                    validator: (value) {
                                      if (value.isEmpty) {
                                        return 'Please enter Address';
                                      } else {
                                        setState(() {
                                          useraddress = value;
                                        });
                                        return null;
                                      }
                                      //to nAVIAGTE AFTER VERIFYING
                                    },
                                    autofocus: true,
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 60,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: dcontroller,
                                    readOnly: true,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      fillColor: Colors.white,
                                      prefixIcon: Icon(Icons.date_range),
                                      hintText: 'Booking Time',
                                    ),
                                    validator: (value) {
                                      if (value.isEmpty)
                                        return 'Choose time';
                                      else
                                        return null;
                                    },
                                    onTap: () async {
                                      TimeOfDay picked = await showTimePicker(
                                          initialTime: initialtime,
                                          context: context,
                                          builder: (BuildContext context,
                                              Widget child) {
                                            return MediaQuery(
                                              data: MediaQuery.of(context)
                                                  .copyWith(
                                                      alwaysUse24HourFormat:
                                                          true),
                                              child: child,
                                            );
                                          });
                                      if (picked != null &&
                                          picked != initialtime)
                                        setState(() {
                                          initialtime = picked;
                                        });
                                      slottime = initialtime
                                          .format(context)
                                          .toString();
                                      dcontroller.text = slottime.toString();
                                      int hr = initialtime.hour + 1;
                                      TimeOfDay t = TimeOfDay(
                                          hour: hr, minute: initialtime.minute);

                                      reservedtime = t.format(context);
                                    },
                                  ),
                                ),
                              ),
                            ),
                          /*  Padding(
                              padding: const EdgeInsets.all(10.0),
                              child: Container(
                                height: 65,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(10.0),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(10.0),
                                  child: TextFormField(
                                    controller: controller,
                                    enabled: false,
                                    decoration: InputDecoration(
                                      border: InputBorder.none,
                                      fillColor: Colors.white,
                                      prefixIcon: Icon(Icons.timelapse_rounded),
                                      hintText: reservedtime,
                                    ),
                                  ),
                                ),
                              ),
                            ),*/
                            SizedBox(
                              height: 50,
                            ),
                            Padding(
                              padding: const EdgeInsets.all(15),
                              child: Container(
                                height: 60,
                                width: double.infinity,
                                child: ElevatedButton(
                                  style: ElevatedButton.styleFrom(
                                      primary: Colors.blueAccent,
                                      elevation: 5,
                                      shape: RoundedRectangleBorder(
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      )),
                                  onPressed: () async {
                                    if (_formKey.currentState.validate()) {
                                      Firebase();
                                    } else {

                                      final snackbar = SnackBar(
                                        content: Text(
                                            'Please Validate the required field'),
                                      );
                                      skey.currentState.showSnackBar(snackbar);
                                    }
                                  },
                                  child: Text('Proceed to Pay',
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold)),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                )),
    );
  }

  Future checking(double booktime, double opentime, double booktill,
      double closetime, double bstime, double x1, double x2, var slotno) async {
    print(bstime);
    String dates = DateFormat.yMMMd().format(DateTime.now()).toString();
    if (booktime >= opentime && booktill <= closetime) {
      if (bstime == 1.0 || (booktime <= x1 || booktime >= x2)) {
        setState(() {
          isloading = true;
        });
        Map<String, dynamic> data = {
          'bookingstatus': 'Confirm',
          'status': 'Success',
          'userphoneno': userno,
          'booktime': slottime,
          'reserve': reservedtime,
          'vehicleno': vno,
          'date': dates,
          'slotno': slotno,
          'username': username,
          'address': useraddress,
          'qrid': (slotno + vno + username + slottime).toString(),
          'createdon': FieldValue.serverTimestamp(),
          'parked': 'Yes',
          'checkin': slottime,
          'checkout': 'Not Yet Checkedout',

        };
        print(data);
        Navigator.push(
            (context),
            MaterialPageRoute(
                builder: (context) => paymentpage(pname: pname, data: data)));
      } else {
        setState(() {
          isloading = false;
        });
        print('Checking new slots');
        //final snackbar = SnackBar(content:new Text('Either Choose time 1.10hr before $slottime  or 1.10hr After $slottime  '),
        final snackbar = SnackBar(
          content: new Text('Choosing next available slot '),
          backgroundColor: Colors.blueAccent,
          behavior: SnackBarBehavior.floating,
          elevation: 5,
        );
        ScaffoldMessenger.of(context).showSnackBar(snackbar);
        Firebase();
      }
    } else {
      setState(() {
        isloading = false;
      });
      final snackbar = SnackBar(
        content: Text('Booking Closed at $endtime  and Open at $starttime'),
        backgroundColor: Colors.blueAccent,
        behavior: SnackBarBehavior.fixed,
        elevation: 5,
      );
      ScaffoldMessenger.of(context).showSnackBar(snackbar);
      print('Choose diff time');
    }
  }

  Future slotfreechecking(String slotno, String dates) {
    opentime = ch(converttime(starttime)); //parking time   s1
    booktime = ch(converttime(slottime)); //user slottime  s2
    closetime = ch(converttime(endtime)); //parking endtime e1
   // booktill = ch(converttime(reservedtime));
    booktill=booktime+1.00;//user end time
    DateTime date = DateTime.now();
    String wday = DateFormat.EEEE().format(date);

    try {
      Firestore.instance
          .collection('parkingDetails')
          .document(park)
          .collection('Slotsbooked')
          .where('slotno', isEqualTo: slotno)
          .where('date', isEqualTo: dates)
          .getDocuments()
          .then((value) {
        print(value.toString());
        if (value.documents.isNotEmpty) {
          value.documents.forEach((element) {
            brtime = element.data['booktime'].toString();
            print(brtime);
            bstime = ch(converttime(brtime));
            x1 = bstime - 1.00;
            x2 = bstime + 1.00;
            checking(booktime, opentime, booktill, closetime, bstime, x1, x2,
                slotno);
          });
        } else {
          bstime = 1.0;
          x1 = bstime - 1.00;
          x2 = bstime + 1.00;
          checking(
              booktime, opentime, booktill, closetime, bstime, x1, x2, slotno);
        }
      });
    } catch (e) {
      print(e);
    }
  }
}
