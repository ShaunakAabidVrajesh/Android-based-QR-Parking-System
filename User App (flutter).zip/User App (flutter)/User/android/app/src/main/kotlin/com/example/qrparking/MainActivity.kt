package com.example.qrparking

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
