
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import    'package:qrparking/homepages/homepage.dart';
import    'package:qrparking/navigationDrawer/tabview.dart';

import 'package:qrparking/navigationDrawer/contactdetails.dart';
import 'package:qrparking/navigationDrawer/createDrawerBodyItem.dart';
import 'file:///E:/qrparking/qrparking/lib/profilepages/userprofile.dart';


import '../splashscreen.dart';

class navigationDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: <Widget>[
          createDrawerHeader(),
          createDrawerBodyItem(
            icon: Icons.home,
            text: 'Home',
            onTap: () =>
                Navigator.push((context),  MaterialPageRoute( builder: (context) => homepage()))
          ),
          createDrawerBodyItem(
            icon: Icons.account_circle,
            text: 'Profile',
            onTap: () =>Navigator.push((context), MaterialPageRoute(builder: (context)=>userprofile()))
               // Navigator.pushReplacementNamed(context, pageRoutes.profile),
          ),

          createDrawerBodyItem(
            icon: Icons.bookmarks,
            text: 'Bookings',
            onTap: () =>
                Navigator.push((context), MaterialPageRoute(builder: (context)=>tabs()))
          ),
         /* createDrawerBodyItem(
              icon: Icons.history,
              text: 'Booking History',
              onTap: () async{

                Navigator.push(context, MaterialPageRoute(builder: (context)=>bookinghistory()));
              }
          ),*/
          Divider(),
          createDrawerBodyItem(
              icon: Icons.contact_phone,
              text: 'Contact Info',
              onTap: () { Navigator.of(context).pop();
              Navigator.push(context, MaterialPageRoute(builder: (context)=>contactdetails()));}
          ),
          createDrawerBodyItem(
            icon: Icons.logout,
            text: 'Log Out',
            onTap: () async{
              await FirebaseAuth.instance.signOut();
              Navigator.of(context).pop();
               Navigator.push(context, MaterialPageRoute(builder: (context)=>SplashScreen()));
            }
          ),

          ListTile(
            title: Text('App version 1.0.0'),
            onTap: () {},
          ),
        ],
      ),
    );
  }

  Widget createDrawerHeader() {
    return DrawerHeader(
        margin: EdgeInsets.zero,
        padding: EdgeInsets.zero,
        decoration: BoxDecoration(
          color: Colors.blueAccent,
            image: DecorationImage(
              
                fit: BoxFit.fill,
                image:  AssetImage('assets/images/qr-code.png'))),
        child: Stack(children: <Widget>[
          Positioned(
              left: 25.0,
              bottom: 5.0,
              child: Text("QrParking",
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 20.0,
                      fontWeight: FontWeight.bold))),

        ]));
  }
}