import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qrparking/bookinghistory/bookinghistory.dart';
import 'package:qrparking/bookinghistory/cancelbookings.dart';
import 'package:qrparking/homepages/bookingpage.dart';
import 'package:qrparking/navigationDrawer/navigationDrawer.dart';


class tabs extends StatefulWidget {
  @override
  _tabsState createState() => _tabsState();
}

class _tabsState extends State<tabs> {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          bottom: TabBar(
            indicatorColor: Colors.white,
            tabs: [
              Tab(icon: Icon(Icons.flash_on_rounded ,semanticLabel: 'Current',)),
              Tab(icon: Icon( Icons.history,semanticLabel: 'History',)),
              Tab(icon: Icon(Icons.cancel_rounded)),

            ],
          ),
          elevation: 6,

          title: Text('Bookings'),
            backgroundColor: Colors.blueAccent
        ),
        drawer: navigationDrawer(),
        body: TabBarView(
          children: [
           new userbookingsdetails(),
            new bookinghistory(),
            new cancelled(),
          ],
        ),
      ),
    );
  }
}
