import 'dart:core';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/rendering.dart';
import 'package:qrparking/homepages/homepage.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:qrparking/navigationDrawer/navigationDrawer.dart';
class contactdetails extends StatefulWidget{

  @override
  State createState() => _contactdetails();
}

class _contactdetails extends State<contactdetails> {


String email='qrparking2@gmail.com';
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async{
        Navigator.push((context),  MaterialPageRoute( builder: (context) => homepage()));
        return true;
      },
      child: SafeArea(
        child: Scaffold(
          backgroundColor: Colors.white,
          appBar: AppBar(
            title: Text(
              "App Details",
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.white,
              ),
            ),
            backgroundColor: Colors.blueAccent,
            elevation: 10,
            centerTitle: true,

          ),
          drawer: navigationDrawer(),
          body: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                SizedBox(height: 15,),
                Center(
                  child: Container(
                      width: 140.0,
                      height: 140.0,
                      decoration: new BoxDecoration(
                        shape: BoxShape.circle,
                        image: new DecorationImage(
                          image: new ExactAssetImage(
                              'assets/images/qr-code.png'),
                          fit: BoxFit.cover,
                        ),
                      )),
                ),

                SizedBox(height: 35,),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.apps,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 5,),
                      Text(
                        'App Name :',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                            fontSize: 13
                        ),
                      ),
                      SizedBox(width: 5,),
                      Text(
                        'Qr Parking',
                        style: TextStyle(
                          fontWeight: FontWeight.w700,
                          fontSize: 20,fontFamily:'Roboto',
                          color: Colors.indigo,
                        ),
                      ),

                    ],
                  ),
                ),

                SizedBox(height: 15,),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0, right: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: <Widget>[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.email_rounded,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 5,),

                      Text(
                        'Email Id :',
                        style: TextStyle(
                           fontWeight: FontWeight.w600,
                            color: Colors.black,
                            fontSize: 13
                        ),
                      ),
                      SizedBox(width: 5,),
                      GestureDetector(
                        child: Text(
                          'qrparking@gmail.com',
                          style: TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 20,
                            color:Colors.green,
                          ),
                        ),
                        onTap: (){
                          launch("mailto:$email");
                        },
                      ),

                    ],
                  ),
                ),


                SizedBox(height: 15,),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.add_location_rounded,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 5,),
                      Text(
                        'Full Address :',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                            fontSize: 13,
                            letterSpacing: 0.2
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 8,),
                Padding(
                  padding: const EdgeInsets.only(left: 55.0),
                  child:  Text(
                    'Bahusaheb Bandekar Technical Education Complex,It Department,Farmagudi, Ponda, Goa-403401',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: Colors.indigo,
                        fontSize: 14,
                        letterSpacing: 0.2
                    ),
                  ),
                ),

                SizedBox(height: 8,),
                Padding(
                  padding: const EdgeInsets.only(left: 10.0),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.devices_rounded,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 5,),

                      Text(
                        'Developed by :',
                        style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: Colors.black,
                            fontSize: 13,
                            letterSpacing: 0.2
                        ),
                      ),
                      SizedBox(width: 5,),
                      Text(
                        'AVS Developers',
                        style: TextStyle(
                            fontWeight: FontWeight.w700,
                            color: Colors.indigo,
                            fontSize: 16.4,
                            letterSpacing: 0.2
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 30,),

                Flexible(
                  child: Text(
                    'Please give us the Feedback by a click on the Email Id',
                    style: TextStyle(

                        color: Colors.grey[600],
                        fontSize: 14,
                        letterSpacing: 0.2
                    ),
                  ),
                ),
                SizedBox(height: 70,),

                Align(
                  alignment: Alignment.bottomCenter,
                  child: Text(
                    'Copywright@ 2021,AVS Developers',
                    style: TextStyle(

                        color: Colors.grey[400],
                        fontSize: 14,
                        letterSpacing: 0.2
                    ),
                  ),
                ),


              ],
            ),
          ),
        ),
      ),
    );
  }
}