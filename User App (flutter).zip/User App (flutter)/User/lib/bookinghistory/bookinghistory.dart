import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:qrparking/bookinghistory/historydetails.dart';
//import 'package:qrparking/navigationDrawer/navigationDrawer.dart';

final FirebaseAuth auth=FirebaseAuth.instance;
// ignore: non_constant_identifier_names
var name,slotno,booktime,reservetime,address;String Userid;

// ignore: camel_case_types
class bookinghistory extends StatefulWidget {
  @override
  _bookinghistoryState createState() => _bookinghistoryState();
}

class _bookinghistoryState extends State<bookinghistory> {
  @override
  void initState() {
    // TODO: implement initStat
    getcurrentuserid();
    //   Firebase();
    //
    super.initState();
  }
  getcurrentuserid() async{
    final FirebaseUser user=await auth.currentUser();
    final userid=user.uid.toString();
    Userid=userid;
    // return userid;
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
        child: Container(
          //  margin: EdgeInsets.only(top: 60),
          width:  MediaQuery.of(context).size.width,
          height:  MediaQuery.of(context).size.height * 1.5,

          child: StreamBuilder<QuerySnapshot>(
              stream: Firestore.instance.collection('users').document(Userid).collection('Bookings').orderBy('createdon',descending: true).snapshots(),
              /*where('booking',isEqualTo:'Confirm')*/

              builder: (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError)
                  return new Text('Error: ${snapshot.error}');
                switch (snapshot.connectionState) {
                  case ConnectionState.waiting:
                    return new Center(child: new Text('Loading...'));
                  default:
                    return new GridView(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        // childAspectRatio: 0.60,
                        mainAxisSpacing: 15,
                        crossAxisSpacing: 15,

                      ),


                      padding: EdgeInsets.all(20),
                      scrollDirection: Axis.vertical,
                      children: snapshot.data.documents.map((
                          DocumentSnapshot document){
                        return new CustomCard(
                          name: document['parkingname'].toString().toUpperCase(),
                          booktime: document['booktime'],
                          reserve:document['reserve'],
                          slotno:document['slotno'],
                          address:document['address'],
                          date:document['date'].toString(),
                          qrid: document['qrid'],
                          vehicleno: document['vehicleno'],
                          parked: document['parked'],
                          booking: document['booking'],
                          fee:  document['fee'].toString(),
                          status:  document['status'],
                          txnid:  document['txnid'],
                          txtrefno:  document['txtrefno'],
                          phno: document['phno'],
                          userid: Userid,
                          checkedin: document['checkedin'],
                          checkout: document['checkout'],
                        );
                      }).toList(),
                    );
                }
              }
          ),
        ),

      ),
    );
  }
}
