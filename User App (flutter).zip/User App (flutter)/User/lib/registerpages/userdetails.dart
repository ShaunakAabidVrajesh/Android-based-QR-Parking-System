import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:encrypt/encrypt.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:qrparking/homepages/homepage.dart';
//import 'package:encrypt/encrypt.dart' as encrypt;
//import 'package:flutter_string_encryption/flutter_string_encryption.dart';
//import 'dart:math';

// ignore: camel_case_types
class userdetails extends StatefulWidget {
  final String phnumber;

  userdetails({key, this.phnumber}) : super(key: key);
  @override
  _userdetailsState createState() => _userdetailsState(phnumber);
}

// ignore: camel_case_types
class _userdetailsState extends State<userdetails> {
  // ignore: non_constant_identifier_names
  String phnumber, Userid;bool enable=false;
  _userdetailsState(this.phnumber);

  final skey = GlobalKey<ScaffoldState>();
  String names, address, confirmpassword;
//  final _controller=TextEditingController();
  final controller = TextEditingController();
  FocusNode name = FocusNode();
  FocusNode passvalue = FocusNode();
  FocusNode confpass = FocusNode();
  bool isError = false;
  final _formKey = GlobalKey<FormState>();
  bool obsecure = false;
  bool secure = false;
  bool isloading = false;
  String get mobile => phnumber;
  String encrypted, decrypted;
  String password, users;
  final FirebaseAuth auth = FirebaseAuth.instance;
  var key;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getcurrentuserid();
  }

  getcurrentuserid() async {
    final FirebaseUser user = await auth.currentUser();
    final userid = user.uid.toString();
    setState(() {
      Userid = userid;
    });
    return userid;
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async => false,
      child: SafeArea(
        child: Scaffold(
            key: skey,
            appBar: AppBar(
               automaticallyImplyLeading: false,
              title: Text(
                "Enter the Details",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
              backgroundColor: Colors.blueAccent,
              elevation: 10,
              centerTitle: true,
              textTheme: Theme.of(context).textTheme,
            ),
            body: isloading
                ? Center(
                    child: CircularProgressIndicator(
                    valueColor:
                        new AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                  ))
                : Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    child: SingleChildScrollView(
                      scrollDirection: Axis.vertical,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          SizedBox(height: 10),
                          Row(
                            children: <Widget>[
                              SizedBox(
                                width: 20,
                              ),
                              Text(
                                "Step 3 ",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    fontWeight: FontWeight.bold, fontSize: 15),
                              ),
                              Text(
                                "of 3",
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                    color: Colors.black26, fontSize: 12),
                              ),
                            ],
                          ),
                          SizedBox(height: 50),
                          Form(
                            key: _formKey,
                            child: Column(
                              children: <Widget>[
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Container(
                                    height: 60,
                                    decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                        border: Border.all(
                                            color: Colors.blueAccent),
                                        boxShadow: [
                                           BoxShadow(
                                            color: Colors.black12,
                                            offset: Offset(0.0, 2.0),
                                            blurRadius: 5.0,
                                          )
                                        ]),
                                    child: Padding(
                                      padding: EdgeInsets.all(10.0),
                                      child: GestureDetector(
                                        onTap: (){
                                          setState(() {
                                            enable=true;
                                          });
                                        },
                                        child: TextFormField(
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            fillColor: Colors.white,
                                            prefixIcon: Icon(
                                              Icons.account_circle,
                                            ),
                                            //  suffixIcon: Icon(Icons.check_circle_outline,color: Colors.black26,),
                                            counterText: '',
                                            hintText: 'Name',
                                            errorStyle: TextStyle(height: 0.3),
                                          ),
                                          maxLength: 30,
                                          autofocus: true,
                                          keyboardType: TextInputType.text,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return 'Please enter Name';
                                            } else {
                                              setState(() {
                                                names = value;
                                              });
                                              return null;
                                            }
                                          },
                                          focusNode: name,
                                          onFieldSubmitted: (n) {
                                            fieldFocusChange(
                                                context, name, passvalue);
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Container(
                                    height: 60,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border:
                                          Border.all(color: Colors.blueAccent),
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.black12,
                                          offset: Offset(0.0, 2.0),
                                          blurRadius: 5.0,
                                        )
                                      ],
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.all(10.0),
                                      child: Row(
                                        children: [
                                          Card(
                                            child: Padding(
                                              padding:
                                                  const EdgeInsets.all(2.0),
                                              child: Icon(
                                                Icons.account_circle,
                                                size: 18,
                                                color: Colors.white,
                                              ),
                                            ),
                                            color: Colors.blueAccent,
                                          ),
                                          SizedBox(
                                            width: 4,
                                          ),
                                          new Text(
                                            '$phnumber',
                                            style: TextStyle(
                                                fontSize: 14.0,
                                                color: Colors.black45),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.all(10.0),
                                  child: Container(
                                    height: 60,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      border:
                                          Border.all(color: Colors.blueAccent),
                                      boxShadow: [
                                         BoxShadow(
                                          color: Colors.black12,
                                          offset: Offset(0.0, 2.0),
                                          blurRadius: 5.0,
                                        )
                                      ],
                                      borderRadius: BorderRadius.circular(10.0),
                                    ),
                                    child: Padding(
                                      padding: EdgeInsets.all(10.0),
                                      child: GestureDetector(
                                        onTap: (){
                                          setState(() {
                                            enable=true;
                                          });
                                        },
                                        child: TextFormField(
                                          decoration: InputDecoration(
                                            border: InputBorder.none,
                                            fillColor: Colors.white,
                                            prefixIcon: Icon(
                                              Icons.add_location_alt_rounded,
                                            ),
                                            //  suffixIcon: Icon(Icons.check_circle_outline,color: Colors.black26,),
                                            counterText: '',
                                            hintText: 'Address',
                                            errorStyle: TextStyle(height: 0.3),
                                          ),
                                          maxLength: 50,
                                          keyboardType: TextInputType.text,
                                          validator: (value) {
                                            if (value.isEmpty) {
                                              return 'Please enter Address';
                                            } else {
                                              setState(() {
                                                address = value;
                                              });
                                              return null;
                                            }
                                            //to nAVIAGTE AFTER VERIFYING
                                          },
                                          autofocus: true,
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height:
                                      MediaQuery.of(context).size.height * 0.25,
                                ),
                                Align(
                                  alignment: Alignment.bottomCenter,
                                  child: Padding(
                                    padding: const EdgeInsets.all(15),
                                    child: Container(
                                        height: 57,
                                        width: double.infinity,
                                        child: ElevatedButton(
                                          style: ElevatedButton.styleFrom(
                                            primary: Colors.blueAccent,
                                            elevation: 10,
                                            shape: RoundedRectangleBorder(
                                              borderRadius:
                                                  BorderRadius.circular(10.0),
                                            ),
                                          ),
                                          onPressed: () async {
                                            final CollectionReference User =
                                                Firestore.instance
                                                    .collection('users');

                                            if (_formKey.currentState
                                                .validate()) {
                                              setState(() {
                                                isloading = true;
                                              });
                                              print(Userid);

                                              try {
                                                await User.document(Userid)
                                                    .setData({
                                                  'createdon': FieldValue
                                                      .serverTimestamp(),
                                                  'userid': Userid,
                                                  'mobileno': widget.phnumber,
                                                  'name': names,
                                                  'address': address,
                                                }).then((value) => Navigator.push(
                                                        (context),
                                                        MaterialPageRoute(
                                                            builder: (context) =>
                                                                homepage())));
                                              } catch (e) {
                                                print(e);
                                              }
                                            } else {
                                              final snackbar = SnackBar(
                                                content: Text(
                                                    'Please Validate the required field'),
                                              );
                                              ScaffoldMessenger.of(context)
                                                  .showSnackBar(snackbar);
                                            }
                                          },
                                          child: Text('Done',
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold)),
                                        )),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  )),
      ),
    );
  }
}

void fieldFocusChange(
    BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
  currentFocus.unfocus();
  FocusScope.of(context).requestFocus(nextFocus);
}
