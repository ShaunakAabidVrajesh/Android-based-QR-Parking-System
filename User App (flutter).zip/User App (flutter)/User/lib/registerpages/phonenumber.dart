import 'dart:async';

import 'package:android_intent/android_intent.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qrparking/registerpages/userdetails.dart';
import 'verify.dart';
import 'package:country_code_picker/country_code_picker.dart';
import 'package:flutter/services.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:connectivity/connectivity.dart';
import 'package:qrparking/internet.dart';

// ignore: camel_case_types
class register extends StatefulWidget {
  @override
  _registerState createState() => _registerState();
}

// ignore: camel_case_types
class _registerState extends State<register> {
  bool isLoading, internet;
  String _phoneNumber;
  String countrycode = "+91";
  final _formKey = GlobalKey<FormState>();
  final _controller = TextEditingController();
  final skey = GlobalKey<ScaffoldState>();
  final FirebaseAuth auth = FirebaseAuth.instance;
  String Userid;
  Map _source = {ConnectivityResult.none: false};
  MyConnectivity _connectivity = MyConnectivity.instance;
  @override
  void initState() {
    isLoading = false;
    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      setState(() => _source = source);
    });
    // TODO: implement initState
    super.initState();

    //Encrypt();
  }

  @override
  Widget build(BuildContext context) {
    switch (_source.keys.toList()[0]) {
      case ConnectivityResult.none:
        setState(() {
          internet = false;
        });

        break;
      case ConnectivityResult.mobile:
        setState(() {
          internet = true;
        });
        break;
      case ConnectivityResult.wifi:
        setState(() {
          internet = true;
        });
    }

    return Scaffold(
      key: skey,
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          color: Colors.white,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        elevation: 10,
        title: Text(
          "Phone Number",
          style: TextStyle(
            fontFamily: 'Roboto',
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blueAccent,
        centerTitle: true,
        textTheme: Theme.of(context).textTheme,
      ),
      body: new Container(
        width: MediaQuery.of(context).size.width,
        height: MediaQuery.of(context).size.height,
        child: isLoading
            ? Center(
                child: Container(width: 50,height: 50,
                  child: CircularProgressIndicator(
                  valueColor:
                      new AlwaysStoppedAnimation<Color>(Colors.blueAccent),
              ),
                ))
            : Column(
                //mainAxisAlignment: MainAxisAlignment.spaceEvenly,

                children: <Widget>[
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.03,
                  ),
                  Row(
                    children: <Widget>[
                      SizedBox(
                        width: 20,
                      ),
                      Text(
                        "Step 1",
                        textAlign: TextAlign.left,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      Text(
                        "of 3",
                        textAlign: TextAlign.left,
                        style: TextStyle(color: Colors.black26, fontSize: 12),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.20, //130,
                    child: Image.asset('assets/images/qr-code.png'),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.04,
                  ),
                  Text(
                    'Enter your phone number',
                    style: TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 15,
                        color: Colors.blueAccent),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Padding(
                          padding: const EdgeInsets.all(15.0),
                          child: Container(
                            height: 60, //60,

                            decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(10.0),
                                border: Border.all(color: Colors.blueAccent),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black12,
                                    offset: Offset(0.0, 2.0),
                                    blurRadius: 5.0,
                                  )
                                ]),
                            child: Padding(
                              padding:
                                  EdgeInsets.only(left: 15, right: 15, top: 5),
                              child: TextFormField(
                                  decoration: InputDecoration(
                                    counterText: '',
                                    border: InputBorder.none,
                                    errorStyle: TextStyle(height: 0.3),
                                    fillColor: Colors.white,
                                    prefixIcon: CountryCodePicker(
                                      onChanged: (e) => print(e.toLongString()),
                                      initialSelection: 'IN',
                                      enabled: false,
                                      showFlag: true,
                                      favorite: ['+91', 'IN'],
                                      hideSearch: true,
                                    ),
                                  ),
                                  autofocus: true,
                                  maxLength: 10,
                                  controller: _controller,
                                  keyboardType: TextInputType.number,
                                  inputFormatters: [
                                    FilteringTextInputFormatter.digitsOnly
                                  ],
                                  validator: (value) {
                                    if (value.isEmpty) {
                                      return 'Mobile Number must not be empty';
                                    } else if (value.length != 10) {
                                      _controller.clear();
                                      return 'Mobile Number must be 10 digit';
                                    } else {
                                      setState(() {
                                        _phoneNumber = countrycode + value;
                                      });
                                      return null;

                                      //to nAVIAGTE AFTER VERIFYING
                                    }
                                  }),
                            ),
                          ),
                        ),
                        SizedBox(
                            height: MediaQuery.of(context).size.height *
                                0.29), //230
                        Align(
                          alignment: Alignment.bottomCenter,
                          child: Padding(
                            padding: const EdgeInsets.all(15),
                            child: Container(
                              height: 55,
                              width: double.infinity,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                    primary: Colors.blueAccent,
                                    elevation: 10,
                                    shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(10.0),
                                    )),
                                onPressed: () async {
                                  if (_formKey.currentState.validate()) {
                                    print(internet);
                                    if (internet == true) {

                                                verifyPhoneNumber();

                                    } else {
                                      return showDialog(
                                          context: context,
                                          builder: (BuildContext context) {
                                            return AlertDialog(
                                              title: Text(
                                                'Internet Permission',
                                                style: TextStyle(
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                              content: const Text(
                                                  'Please make sure you enable Internet & has stable connection and try again'),
                                              actions: <Widget>[
                                                ElevatedButton(
                                                    child: Text('Ok'),
                                                    onPressed: () {
                                                      final AndroidIntent
                                                          intent =
                                                          AndroidIntent(
                                                              action:
                                                                  'android.settings.SETTINGS');
                                                      intent.launch();
                                                      Navigator.of(context,
                                                              rootNavigator:
                                                                  true)
                                                          .pop();
                                                    }),
                                              ],
                                            );
                                          });
                                    }
                                  } else {
                                    final snackbar = SnackBar(
                                      content: Text('Validated the field'),
                                    );
                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackbar);
                                  }
                                },
                                child: Text('Continue',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    )),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
      ),
    );
  }

  void verifyPhoneNumber() async {
    setState(() {
      isLoading = true;
    });
    final FirebaseAuth auth = FirebaseAuth.instance;
    PhoneVerificationFailed verificationFailed =
        (AuthException authException) async {
      print(authException.code);
    };

    PhoneCodeSent codeSent =
        (String verificationId, [int forceresendingToken]) async {
      //  Scaffold.of(context).showSnackBar(SnackBar(content: Text("OTP Sent Successfully"),duration:Duration(seconds: 5),));
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => verify(
                    phoneNumber: '$_phoneNumber',
                    verificationId: verificationId,
                  )));

      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('OTP send Successfully')));
    };

    PhoneVerificationCompleted verificationCompleted =
        (AuthCredential credential) async {
      await auth.signInWithCredential(credential);

      Navigator.pop(context);
      Navigator.push(
          context,
          MaterialPageRoute(
              builder: (context) => userdetails(phnumber: _phoneNumber)));
    };
    try {
      await auth.verifyPhoneNumber(
          phoneNumber: '$_phoneNumber',
          timeout: Duration(seconds: 20),
          verificationCompleted: verificationCompleted,
          verificationFailed: verificationFailed,
          codeSent: codeSent,
          codeAutoRetrievalTimeout: null);
    } catch (e) {
      print(e);
    }
  }

  @override
  void dispose() {

    isLoading = false;
    _connectivity.disposeStream();
    super.dispose();
  }
}
