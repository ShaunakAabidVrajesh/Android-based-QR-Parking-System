// TODO Implement this library.
import 'package:flutter/material.dart';
import 'package:pinput/pin_put/pin_put.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:qrparking/registerpages/userdetails.dart';

// ignore: camel_case_types
class verify extends StatefulWidget {
  const verify({Key key, this.phoneNumber, this.verificationId})
      : super(key: key);
  final String phoneNumber;
  final String verificationId;
  @override
  _verifyState createState() => _verifyState();
}

// ignore: camel_case_types
class _verifyState extends State<verify> {
  final GlobalKey<ScaffoldState> _scaffoldkey = GlobalKey<ScaffoldState>();
  String otp;
  bool isloading = false;
  final TextEditingController _pinPutController = TextEditingController();
  final FocusNode _pinPutFocusNode = FocusNode();
  final BoxDecoration pinPutDecoration = BoxDecoration(
    color: Colors.blueAccent,
    borderRadius: BorderRadius.circular(10.0),
  );

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async=>false,
      child: SafeArea(
        child: Scaffold(
          key: _scaffoldkey,
          appBar: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Colors.blueAccent,
            title: Text('OTP Verification'),
            elevation: 10,
          ),
          body: isloading
              ? Center(
                  child: Container(
                    width: 50,height: 50,
                    child: CircularProgressIndicator(
                    valueColor:
                        new AlwaysStoppedAnimation<Color>(Colors.blueAccent),
                ),
                  ))
              : Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  child: Column(
                    children: [
                      SizedBox(
                        height: MediaQuery.of(context).size.height * 0.03,
                      ),
                      Row(
                        children: <Widget>[
                          SizedBox(
                            width: 20,
                          ),
                          Text(
                            "Step 2",
                            textAlign: TextAlign.left,
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 15),
                          ),
                          Text(
                            "of 3",
                            textAlign: TextAlign.left,
                            style: TextStyle(color: Colors.black26, fontSize: 12),
                          ),
                        ],
                      ),
                      SizedBox(
                        width: 50,
                      ),
                      Container(
                        margin: EdgeInsets.only(top: 40),
                        child: Center(
                          child: Text(
                            'Verify ${widget.phoneNumber}',
                            style: TextStyle(
                                fontWeight: FontWeight.bold, fontSize: 24),
                          ),
                        ),
                      ),
                      Padding(
                          padding: const EdgeInsets.all(30.0),
                          child: PinPut(
                            fieldsCount: 6,
                            textStyle: const TextStyle(
                                fontSize: 25.0, color: Colors.white),
                            eachFieldWidth: 40.0,
                            eachFieldHeight: 50.0,
                            focusNode: _pinPutFocusNode,
                            controller: _pinPutController,
                            submittedFieldDecoration: pinPutDecoration,
                            selectedFieldDecoration: pinPutDecoration,
                            followingFieldDecoration: pinPutDecoration,
                            pinAnimationType: PinAnimationType.fade,
                            onSubmit: (v) {
                              setState(() {
                                otp = v;
                              });
                            },
                            validator: (s) {
                              if (s.isEmpty)
                                return 'Not Valid';
                              else
                                return null;
                            },
                          )),
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Padding(
                          padding: EdgeInsets.all(15),
                          child: Container(
                              height: 57,
                              width: double.infinity,
                              child: ElevatedButton(
                                style: ElevatedButton.styleFrom(
                                  primary: Colors.blueAccent,
                                  elevation: 10,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  ),
                                ),
                                onPressed: () {
                                  if (_pinPutController != null) {
                                    setState(() {
                                      isloading = true;
                                    });
                                    signInwithnumber();
                                  } else {
                                    final snackbar = SnackBar(
                                      content: Text('Validated the field'),
                                      backgroundColor: Colors.blueAccent,
                                      behavior: SnackBarBehavior.fixed,
                                      elevation: 5,
                                    );

                                    ScaffoldMessenger.of(context)
                                        .showSnackBar(snackbar);
                                    return 'Empty or incorrect';
                                  }
                                },
                                child: Text('Verify and Continue',
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                    )),
                              )),
                        ),
                      ),
                    ],
                  ),
                ),
        ),
      ),
    );
  }

  void signInwithnumber() async {
    try {
      final AuthCredential credential = PhoneAuthProvider.getCredential(
          verificationId: widget.verificationId, smsCode: otp);
      AuthResult result;
      final FirebaseAuth auth = FirebaseAuth.instance;
      try {
        result = await auth.signInWithCredential(credential);
        if (result.user.uid != null) Navigator.pop(context);
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) =>
                    userdetails(phnumber: widget.phoneNumber)));
      } catch (e) {
        print(e);
      }
      print(result);
    } catch (e) {
      print(e);
    }
  } //submitng otp

}
