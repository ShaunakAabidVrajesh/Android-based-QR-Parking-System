

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

// ignore: must_be_immutable
class ProfilePage extends StatefulWidget {
  ProfilePage({ this.name, this.phno,this.userid,this.address});

  var name;
  final address,userid,phno;
 // DateTime date;
  @override
  MapScreenState createState() => MapScreenState(name,phno,userid,address);
}

class MapScreenState extends State<ProfilePage> {


  String Userid;//year
  final FirebaseAuth auth=FirebaseAuth.instance;

  String Name,phone,pincode;

  MapScreenState(this.name,this.phno,this.userid,this.address);
  final name;
  final address,userid,phno;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();


  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        body: new Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          color: Colors.white,
          child:new Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              SizedBox(height:20),
              Center(
                child: new Container(
                    width: 140.0,
                    height: 140.0,
                    decoration: new BoxDecoration(
                      shape: BoxShape.circle,
                      image: new DecorationImage(
                        image: new ExactAssetImage(
                            'assets/images/qr-code.png'),
                        fit: BoxFit.cover,
                      ),
                    )),
              ),
              new Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 25.0),
                  child: new Text(
                    'Personal Information',
                    style: TextStyle(
                        fontSize: 18.0,color:Colors.blueAccent,
                        fontWeight: FontWeight.bold),
                  )),

              new Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 25.0),
                  child: new Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.account_circle,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 4,),
                      new Text(
                        'Name',
                        style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.black45),
                      ),
                    ],
                  )),
             new  Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 2.0),
                  child: new Text('$name',style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold),
                  )),
              //name

             new  Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 25.0),
                  child: new Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.call,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 4,),
                      new Text(
                        'Phone Number',
                        style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.black45),
                      ),
                    ],
                  )),
              new Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 2.0),
                  child: new Text('$phno',style: TextStyle(
                    fontSize: 18.0,fontWeight: FontWeight.bold
                    // color: Colors.black45),
                  ),
                  ),),
//phno)
             new Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 25.0),
                  child: new Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    mainAxisSize: MainAxisSize.max,
                    children: <Widget>[
                      Card(
                        child: Padding(
                          padding: const EdgeInsets.all(2.0),
                          child: Icon(
                            Icons.contact_mail,
                            size: 18,
                            color: Colors.white,
                          ),
                        ),
                        color: Colors.blueAccent,
                        elevation: 5,
                      ),
                      SizedBox(width: 4,),
                      new Text(
                        'Address',
                        style: TextStyle(
                            fontSize: 14.0,
                            color: Colors.black45),
                      ),
                    ],
                  )),
             new Padding(
                  padding: EdgeInsets.only(
                      left: 25.0, right: 25.0, top: 2.0),
                  child: new Text('$address', style: TextStyle(
                      fontSize: 18.0,fontWeight: FontWeight.bold
                     // color: Colors.black45),
                  ),
                  ),
              )
            ],
          ),
        ));
  }


}