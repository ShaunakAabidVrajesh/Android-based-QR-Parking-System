import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:qrparking/homepages/homepage.dart';
import 'package:qrparking/profilepages/userinfo.dart';
import 'package:qrparking/navigationDrawer/navigationDrawer.dart';

class userprofile extends StatefulWidget {
  @override
  _userprofileState createState() => _userprofileState();
}
var name, address;final FirebaseAuth auth = FirebaseAuth.instance;
var Userid, phno;
class _userprofileState extends State<userprofile> {
  void initState() {
    // TODO: implement initStat

    getcurrentuserid();

    //   Firebase();
    //
    super.initState();
  }

  getcurrentuserid() async {
    final FirebaseUser user = await auth.currentUser();
    final userid = user.uid.toString();
    Userid = userid;
    // getdata(Userid);
    // return userid;
  }


  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async{
        Navigator.push((context), MaterialPageRoute(builder: (context) =>
            homepage()));
         return true;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text("Profile",style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),),
          centerTitle: true,
          backgroundColor: Colors.blueAccent,
          elevation: 10,

        ),
        drawer: navigationDrawer(),
        body: new Center(
          child: FutureBuilder<DocumentSnapshot>(
              future: Firestore.instance.collection('users').document(Userid).get(),
              builder: (BuildContext context,AsyncSnapshot<DocumentSnapshot> snapshot){
                if(snapshot.hasError) return Text("Error is found in retriving");
                if(snapshot.hasData && !snapshot.data.exists){
                  Navigator.pop(context);
                  return new userprofile();
                }
                if(snapshot.connectionState==ConnectionState.done){
                  return new ProfilePage(
                    userid: Userid,name: snapshot.data['name'],phno: snapshot.data['mobileno'],address: snapshot.data['address'],
                  );
                }
                return Center(child: Text('Loading....'),);
              }),
        ),),
    );
  }
}
/*
class ProfilePage extends StatefulWidget {
  ProfilePage({ this.name, this.phno,this.userid,this.address});

  var name;
  final address,userid,phno;
  // DateTime date;
  @override
  MapScreenState createState() => MapScreenState(name,phno,userid,address);
}

class MapScreenState extends State<ProfilePage> {
  final FocusNode myFocusNode = FocusNode();

  String Userid;//year
  final FirebaseAuth auth=FirebaseAuth.instance;

  String Name,phone,pincode;

  MapScreenState(this.name,this.phno,this.userid,this.address);
  final name;
  final address,userid,phno;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();


  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
        body: new Container(
          color: Colors.white,
          child: new ListView(
            children: <Widget>[
              Column(
                children: <Widget>[
                  new Container(
                    height: 200.0,
                    color: Colors.white,
                    child: new Column(
                      children: <Widget>[
                        */
/*  Padding(
                            padding: EdgeInsets.only(left: 20.0, top: 20.0),
                            child: new Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                new Icon(
                                  Icons.arrow_back_ios,
                                  color: Colors.black,
                                  size: 22.0,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 25.0),
                                  child: new Text('PROFILE',
                                      style: TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 20.0,
                                          fontFamily: 'sans-serif-light',
                                          color: Colors.black)),
                                )
                              ],
                            )),*//*

                        Padding(
                          padding: EdgeInsets.only(top: 20.0),
                          child: new Stack(fit: StackFit.loose, children: <Widget>[
                            new Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: <Widget>[
                                new Container(
                                    width: 140.0,
                                    height: 140.0,
                                    decoration: new BoxDecoration(
                                      shape: BoxShape.circle,
                                      image: new DecorationImage(
                                        image: new ExactAssetImage(
                                            'assets/images/qr-code.png'),
                                        fit: BoxFit.cover,
                                      ),
                                    )),
                              ],
                            ),

                          ]),
                        )
                      ],
                    ),
                  ),
                  new Container(
                    color: Color(0xffFFFFFF),
                    child: Padding(
                      padding: EdgeInsets.only(bottom: 25.0),
                      child: new Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: <Widget>[
                          Padding(
                              padding: EdgeInsets.only(
                                  left: 25.0, right: 25.0, top: 25.0),
                              child: new Text(
                                'Personal Information',
                                style: TextStyle(
                                    fontSize: 18.0,
                                    fontWeight: FontWeight.bold),
                              )),

                          Padding(
                              padding: EdgeInsets.only(
                                  left: 25.0, right: 25.0, top: 25.0),
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Card(
                                    child: Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Icon(
                                        Icons.account_circle,
                                        size: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                    color: Colors.blueAccent,
                                    elevation: 5,
                                  ),
                                  SizedBox(width: 4,),
                                  new Text(
                                    'Name',
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        color: Colors.black45),
                                  ),
                                ],
                              )),
                          Padding(
                              padding: EdgeInsets.only(
                                  left: 25.0, right: 25.0, top: 2.0),
                              child: new Flexible(
                                child: new Text('$name',style: TextStyle(fontSize: 18),
                                ),
                              )),
                          //name

                          Padding(
                              padding: EdgeInsets.only(
                                  left: 25.0, right: 25.0, top: 25.0),
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Card(
                                    child: Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Icon(
                                        Icons.call,
                                        size: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                    color: Colors.blueAccent,
                                    elevation: 5,
                                  ),
                                  SizedBox(width: 4,),
                                  new Text(
                                    'Phone Number',
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        color: Colors.black45),
                                  ),
                                ],
                              )),
                          Padding(
                            padding: EdgeInsets.only(
                                left: 25.0, right: 25.0, top: 2.0),
                            child: new Flexible(
                              child: new Text('$phno',style: TextStyle(
                                fontSize: 18.0,
                                // color: Colors.black45),
                              ),
                              ),
                            ),),
//phno)
                          Padding(
                              padding: EdgeInsets.only(
                                  left: 25.0, right: 25.0, top: 25.0),
                              child: new Row(
                                mainAxisAlignment: MainAxisAlignment.start,
                                mainAxisSize: MainAxisSize.max,
                                children: <Widget>[
                                  Card(
                                    child: Padding(
                                      padding: const EdgeInsets.all(2.0),
                                      child: Icon(
                                        Icons.contact_mail,
                                        size: 18,
                                        color: Colors.white,
                                      ),
                                    ),
                                    color: Colors.blueAccent,
                                    elevation: 5,
                                  ),
                                  SizedBox(width: 4,),
                                  new Text(
                                    'Address',
                                    style: TextStyle(
                                        fontSize: 14.0,
                                        color: Colors.black45),
                                  ),
                                ],
                              )),
                          Padding(
                            padding: EdgeInsets.only(
                                left: 25.0, right: 25.0, top: 2.0),
                            child: new Flexible(
                              child: new Text('$address', style: TextStyle(
                                fontSize: 18.0,
                                // color: Colors.black45),
                              ),
                              ),),
                          ),

                        ],
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
        ));
  }

  @override
  void dispose() {
    // Clean up the controller when the Widget is disposed
    myFocusNode.dispose();
    super.dispose();
  }

}*/
