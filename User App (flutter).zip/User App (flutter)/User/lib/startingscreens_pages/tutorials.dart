import 'dart:async';
import 'package:android_intent/android_intent.dart';
import 'package:flutter/material.dart';

import 'package:qrparking/registerpages/phonenumber.dart';
import 'slide.dart';
import 'slide_dots.dart';
import 'slide_item.dart';
import 'package:connectivity/connectivity.dart';
import 'package:qrparking/internet.dart';


class GettingStartedScreen extends StatefulWidget {
  @override
  _GettingStartedScreenState createState() => _GettingStartedScreenState();
}

class _GettingStartedScreenState extends State<GettingStartedScreen> {
  int _currentPage = 0;
  final PageController _pageController = PageController(initialPage: 0);
  Map _source = {ConnectivityResult.none: false};
  MyConnectivity _connectivity = MyConnectivity.instance;bool internet;
  @override
  void initState() {
    super.initState();
    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      setState(() => _source = source);
    });
   // internetcheck();
    Timer.periodic(Duration(seconds: 5), (Timer timer) {
      if (_currentPage < 2) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }

      _pageController.animateToPage(
        _currentPage,
        duration: Duration(milliseconds: 270),
        curve: Curves.easeIn,
      );
    });
  }

  @override


  _onPageChanged(int index) {
    setState(() {
      _currentPage = index;
    });
  }

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        color: Colors.blueAccent,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: <Widget>[
              Expanded(
                child: Stack(
                  alignment: AlignmentDirectional.bottomCenter,
                  children: <Widget>[
                    PageView.builder(
                      scrollDirection: Axis.horizontal,
                      controller: _pageController,
                      onPageChanged: _onPageChanged,
                      itemCount: slideList.length,
                      itemBuilder: (ctx, i) => SlideItem(i),
                    ),
                    Stack(
                      alignment: AlignmentDirectional.topStart,
                      children: <Widget>[
                        Container(
                          margin: const EdgeInsets.only(bottom: 35),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              for(int i = 0; i<slideList.length; i++)
                                if( i == _currentPage )
                                  SlideDots(true)
                                else
                                  SlideDots(false)
                            ],
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Container(
                    height: 50,
                    width:double.infinity,
                    child: ElevatedButton(
                      child: Text(
                        'Getting Started',
                        style: TextStyle(
                          fontSize: 18,
                          fontFamily: 'Roboto',color: Colors.blueAccent,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        padding: const EdgeInsets.all(15),
                        primary: Colors.white,
                        elevation:10,

                      ),

                      onPressed: () {
                        internetcheck();

                      },
                    ),
                  ),
                  //login  button
                  /* Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      Text(
                        'Have an account?',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                        ),
                      ),
                      TextButton(
                        child: Text(
                          'Login',
                          style: TextStyle(fontSize: 18,color: Colors.white, fontFamily: 'Roboto',fontWeight: FontWeight.bold,),
                        ),
                        onPressed: () {
                           Navigator.push((context), MaterialPageRoute(builder: (context)=>login()));
                        },
                      ),
                    ],
                  ),*/
                ],
              )
            ],
          ),
        ),
      ),
    );
  }

   internetcheck() {
     switch (_source.keys.toList()[0]) {
       case ConnectivityResult.none:
         setState(() {
           internet=false   ;
         });

         break;
       case ConnectivityResult.mobile:
         setState(() {
           internet=true   ;
         });
         break;
       case ConnectivityResult.wifi:
         setState(() {
           internet=true   ;
         });
     }
     if(internet==false){
       return showDialog(
           context: context,
           builder: (BuildContext context) {
             return AlertDialog(
               title: Text('Internet Permission',style: TextStyle(fontWeight: FontWeight.bold),),
               content: const Text(
                   'Please make sure you enable Internet and try again'),
               actions: <Widget>[
                 ElevatedButton(
                     child: Text('Ok'),
                     onPressed: () {
                       final AndroidIntent intent =
                       AndroidIntent(
                           action: 'android.settings.SETTINGS');
                       intent.launch();
                       Navigator.of(context,
                           rootNavigator: true)
                           .pop();
                     }),
               ],
             );
           });
     }else{
       Navigator.push((context), MaterialPageRoute(builder: (context)=>register()));
     }
   }
  void dispose() {
    super.dispose();
    _connectivity.disposeStream();
    _pageController.dispose();
  }
}
