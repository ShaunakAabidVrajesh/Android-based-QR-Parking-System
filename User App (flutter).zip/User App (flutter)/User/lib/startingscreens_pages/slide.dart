import 'package:flutter/material.dart';

class Slide {
	final String imageUrl;
	final String title;
	final String description;

	Slide({
		@required this.imageUrl,
		@required this.title,
		@required this.description,
	});
}

final slideList = [
	Slide(
		imageUrl: 'assets/images/park.png',
		title: 'A Cool Way to Get Start',
		description: 'Choose your destination and we will find an available parking spot for you.',
	),
	Slide(
		imageUrl: 'assets/images/img4.png',
		title: 'Easy Payment',
		description: 'Pay in few touches with any payment options.',
	),
	Slide(
		imageUrl: 'assets/images/qr-code.png',
		title: 'Interactive App UI',
		description: 'Easy Check in and Check out.',
	),
];
