import 'dart:core';
import 'dart:math';
import 'package:android_intent/android_intent.dart';
import 'package:intl/intl.dart';
import 'package:connectivity/connectivity.dart';
import 'package:qrparking/internet.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:qrparking/homepages/receipt.dart';
import 'package:upi_india/upi_india.dart';

// ignore: must_be_immutable
class paymentpage extends StatefulWidget {
  final String phonenumber;
  final String docId;
  final date = DateTime.now();

  Map<String, dynamic> data;

  var userid;
  paymentpage({
    Key key,
    this.phonenumber,
    this.docId,
    this.data,
    this.userid,
  }) : super(key: key);
  @override
  _paymentpageState createState() =>
      _paymentpageState(phonenumber, docId, data, userid);
}

class _paymentpageState extends State<paymentpage> {
  var phonenumber;
  var docId;
  double fee;
  var slots;
  var nid;
  Map<String, dynamic> data;

  var userid, address;
  bool internet;
  _paymentpageState(this.phonenumber, this.docId, this.data, this.userid);
  String get mobile => phonenumber;
  String get doc => docId;
  String get UserId => userid;
  String get did => nid;
  String dates = DateFormat.yMMMd().format(DateTime.now());
  Map get values => data;
  final FirebaseAuth auth = FirebaseAuth.instance;
  String Userid;
  TimeOfDay initialtime = TimeOfDay.now();
  var username, userno;
  Map _source = {ConnectivityResult.none: false};
  MyConnectivity _connectivity = MyConnectivity.instance;
  @override
  void initState() {
    _upiIndia.getAllUpiApps(mandatoryTransactionId: false).then((value) {
      setState(() {
        apps = value;
      });
    }).catchError((e) {
      apps = [];
    });
    Firebase(phonenumber, docId);
    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      setState(() => _source = source);
    });

    getcurrentuserid();
    super.initState();
  }

  getcurrentuserid() async {
    final FirebaseUser user = await auth.currentUser();
    final userid = user.uid.toString();
    if (userid == null) {
      setState(() {
        Userid = UserId;
      });
    } else {
      setState(() {
        Userid = userid;
      });
    }

    DocumentReference userbook =
        Firestore.instance.collection('users').document(Userid);
    userbook.get().then((value) => {
          if (value.exists)
            {
              setState(() {
                username = value.data['name'].toString();
                userno = value.data['mobileno'];
              }),
            }
        });
    // return userid;
  }

  var name;
  var upiid, phno;
  final skey = GlobalKey<ScaffoldState>();
  void Firebase(phonenumber, docId) async {
    //Firestore firestore=Firestore.instance;
    DocumentReference db =
        Firestore.instance.collection('parkingDetails').document(docId);
    db.get().then((value) => {
          if (value.exists)
            {
              setState(() {
                fee = double.parse(value.data['fee']);
                slots = value.data['slots'];
                name = value.data['name'];
                upiid = value.data['upiid'];
                address = value.data['address'];
                phno = value.data['phno'];
              }),
              //  print(docId),print(phonenumber),print(pname),
            }
          else
            {
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text('No Data'))),
            }
        });
  }

  final String transactionRef = Random.secure().nextInt(1 << 32).toString();

  Future<UpiResponse> _transaction;
  UpiIndia _upiIndia = UpiIndia();
  List<UpiApp> apps;

  TextStyle header = TextStyle(
    fontSize: 18,
    fontWeight: FontWeight.bold,
  );

  TextStyle value = TextStyle(
    fontWeight: FontWeight.w400,
    fontSize: 14,
  );

  Future<UpiResponse> initiateTransaction(UpiApp app) async {
    return _upiIndia.startTransaction(
      app: app,
      receiverUpiId: upiid,
      receiverName: name,
      transactionRefId: transactionRef,
      transactionNote: 'Not actual. Just an example.',
      amount: fee,
    );
  }

  Widget displayUpiApps() {
    if (apps == null)
      return Center(child: CircularProgressIndicator());
    else if (apps.length == 0)
      return Center(
        child: Text(
          "No apps found to handle transaction.",
          style: header,
        ),
      );
    else
      return SingleChildScrollView(
        scrollDirection: Axis.vertical,
        child: Column(
          children: [
            SizedBox(
              height: 20,
            ),
            Center(child: Text('Cash Payment')),
            Padding(
              padding: const EdgeInsets.all(15),
              child: Container(
                height: 57,
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                      primary: Colors.blueAccent,
                      elevation: 10,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10.0),
                      )),
                  onPressed: () async {
                    if (internet == true) {
                      //   final  CollectionReference slots=Firestore.instance.collection('parkingDetails').document(widget.docId).collection('Slotsavailable');
                      final CollectionReference userbook =
                          Firestore.instance.collection('users');

                      final CollectionReference book =
                          Firestore.instance.collection('parkingDetails');
                      Map<String, dynamic> data2 = {
                        'status': 'Success',
                        'txnid': 'Cash',
                        'txtrefno': 'Cash',
                        'parked': 'No',
                        'bookingstatus': 'Confirm',
                        'date': dates.toString(),
                        'username': username,
                        'userno': userno,
                        'userid': Userid,
                        'userno': phonenumber,
                        'createdon': FieldValue.serverTimestamp(),
                        'checkedin': 'Not Verified yet',
                        'checkout': 'Not Yet Checkedout',
                      };
                      data.addAll(data2);
                      var parkdata = data.values.toList();
                      String slottime = data['booktime'];
                      print(slottime);
                      String slotno = data['slotno'];
                      String endtime = data['reserve'];
                      String vno = data['vehicleno'];
                      String parkname = data['parkingname'];
                      Map<String, dynamic> userdata = {
                        'booking': 'Confirm',
                        'status': 'Success',
                        'txnid': 'Cash',
                        'txtrefno': 'Cash',
                        'booktime': slottime,
                        'reserve': endtime,
                        'vehicleno': vno,
                        'date': dates.toString(),
                        'slotno': slotno,
                        'fee': fee,
                        'parkingname': parkname,
                        'address': address,
                        'parked': 'No',
                        'checkedin': 'Not Verified yet',
                        'checkout': 'Not Yet Checkedout',
                        'qrid': (slotno + vno + Userid + slottime).toString(),
                        'phno': phno,
                        'createdon': FieldValue.serverTimestamp(),
                      };
                      Map<String, dynamic> qrid1 = {
                        'qrid': (slotno + vno + Userid + slottime).toString(),
                      };
                      data.addAll(qrid1);

                      print(data);
                      String qrid =
                          (slotno + vno + Userid + slottime).toString();
                      try {
                        userbook
                            .document(Userid)
                            .collection('Bookings')
                            .document(qrid)
                            .setData(userdata);

                        book
                            .document(widget.docId)
                            .collection('Slotsbooked')
                            .document(qrid)
                            .setData(data)
                            .then((value) => Navigator.push(
                                (context),
                                MaterialPageRoute(
                                    builder: (context) =>
                                        MyRecipt(qrid: qrid, docid: docId))));
                      } catch (e) {
                        print(e);
                        AlertDialog(
                            title: Text('Alert'),
                            content: Text(e),
                            actions: <Widget>[
                              ElevatedButton(
                                  child: Text('Ok'),
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  }),
                            ]);
                      }
                    } else {
                      return showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text(
                                'Internet Permission',
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              content: const Text(
                                  'Please make sure you enable Internet and try again'),
                              actions: <Widget>[
                                ElevatedButton(
                                    child: Text('Ok'),
                                    onPressed: () {
                                      final AndroidIntent intent =
                                          AndroidIntent(
                                              action:
                                                  'android.settings.SETTINGS');
                                      intent.launch();
                                      Navigator.of(context, rootNavigator: true)
                                          .pop();
                                    }),
                              ],
                            );
                          });
                    }
                  },
                  child: Text('Confirm Booking',
                      style: TextStyle(
                          color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
            SizedBox(
              height: 25,
            ),
            Center(child: Text('Online Payment')),
            Align(
              alignment: Alignment.topCenter,
              child: SingleChildScrollView(
                physics: BouncingScrollPhysics(),
                child: Wrap(
                  children: apps.map<Widget>((UpiApp app) {
                    return GestureDetector(
                      onTap: () {
                        _transaction = initiateTransaction(app);
                        setState(() {});
                      },
                      child: Container(
                        height: 100,
                        width: 100,
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Image.memory(
                              app.icon,
                              height: 60,
                              width: 60,
                            ),
                            Text(app.name),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
      );
  }

  String _upiErrorHandler(error) {
    switch (error) {
      case UpiIndiaAppNotInstalledException:
        return 'Requested app not installed on device';
      case UpiIndiaUserCancelledException:
        return 'You cancelled the transaction';
      case UpiIndiaNullResponseException:
        return 'Requested app didn\'t return any response';
      case UpiIndiaInvalidParametersException:
        return 'Requested app cannot handle the transaction';
      default:
        return 'An Unknown error has occurred';
    }
  }

  void _checkTxnStatus(String status) {
    switch (status) {
      case UpiPaymentStatus.SUCCESS:
        print('Transaction Successful');
        break;
      case UpiPaymentStatus.SUBMITTED:
        print('Transaction Submitted');
        break;
      case UpiPaymentStatus.FAILURE:
        print('Transaction Failed');
        break;
      default:
        print('Received an Unknown transaction status');
    }
  }

  Widget displayTransactionData(title, body) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text("$title: ", style: header),
          Flexible(
              child: Text(
            body,
            style: value,
          )),
        ],
      ),
    );
  }
bool set=false;
  @override
  Widget build(BuildContext context) {
    switch (_source.keys.toList()[0]) {
      case ConnectivityResult.none:
        setState(() {
          internet = false;
        });

        break;
      case ConnectivityResult.mobile:
        setState(() {
          internet = true;
        });
        break;
      case ConnectivityResult.wifi:
        setState(() {
          internet = true;
        });
    }
    return Scaffold(
      appBar: AppBar(
       // automaticallyImplyLeading: set ==true?false: true,
        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios),
          color: Colors.white,
          onPressed: () {
            Navigator.pop(context);
          },
        ),
        title: Text('PAYMENT'),
        backgroundColor: Colors.blueAccent,
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: displayUpiApps(),
          ),
          Expanded(
            child: FutureBuilder(
              future: _transaction,
              builder:
                  (BuildContext context, AsyncSnapshot<UpiResponse> snapshot) {
                if (snapshot.connectionState == ConnectionState.done) {
                  if (snapshot.hasError) {
                    return Center(
                      child: Text(
                        _upiErrorHandler(snapshot.error.runtimeType),
                        style: header,
                      ), // Print's text message on screen
                    );
                  }

                  // If we have data then definitely we will have UpiResponse.
                  // It cannot be null
                  UpiResponse _upiResponse = snapshot.data;

                  // Data in UpiResponse can be null. Check before printing
                  String txnId = _upiResponse.transactionId ?? 'N/A';
                  String resCode = _upiResponse.responseCode ?? 'N/A';
                  String txnRef = _upiResponse.transactionRefId ?? 'N/A';
                  String status = _upiResponse.status ?? 'N/A';
                  String approvalRef = _upiResponse.approvalRefNo ?? 'N/A';
                  _checkTxnStatus(status);

                  return Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        displayTransactionData('Transaction Id', txnId),
                        displayTransactionData('Response Code', resCode),
                        displayTransactionData('Reference Id', txnRef),
                        displayTransactionData('Status', status.toUpperCase()),
                        displayTransactionData('Approval No', approvalRef),
                        Padding(
                          padding: const EdgeInsets.all(15),
                          child: Container(
                            height: 55,
                            width: double.infinity,
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  primary: Colors.blueAccent,
                                  elevation: 10,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10.0),
                                  )),
                              onPressed: () async {
                                //   final  CollectionReference slots=Firestore.instance.collection('parkingDetails').document(widget.docId).collection('Slotsavailable');
                                final CollectionReference userbook =
                                    Firestore.instance.collection('users');

                                final CollectionReference book = Firestore
                                    .instance
                                    .collection('parkingDetails');
                                Map<String, dynamic> data2 = {
                                  'status': status,
                                  'txnid': txnId,
                                  'txtrefno': txnRef,
                                  'parked': 'No',
                                  'bookingstatus': 'Confirm',
                                  'date': dates.toString(),
                                  'username': username,
                                  'userno': userno,
                                  'userid': Userid,
                                  'userno': phonenumber,
                                  'checkin': 'Not Verified yet',
                                  'checkout': 'Not Yet Checkedout',
                                  'createdon': FieldValue.serverTimestamp(),
                                };
                                data.addAll(data2);
                                var parkdata = data.values.toList();
                                String slottime = data['booktime'];
                                print(slottime);
                                String slotno = data['slotno'];
                                String endtime = data['reserve'];
                                String vno = data['vehicleno'];
                                String parkname = data['parkingname'];
                                Map<String, dynamic> userdata = {
                                  'booking': 'Confirm',
                                  'status': status,
                                  'txnid': txnId,
                                  'txtrefno': txnRef,
                                  'booktime': slottime,
                                  'reserve': endtime,
                                  'vehicleno': vno,
                                  'date': dates.toString(),
                                  'slotno': slotno,
                                  'fee': fee,
                                  'parkingname': parkname,
                                  'address': address,
                                  'parked': 'No',
                                  'qrid': (slotno + vno + Userid + slottime)
                                      .toString(),
                                  'phno': phno,
                                  'checkedin': 'Not Verified yet',
                                  'checkout': 'Not Yet Checkedout',
                                  'createdon': FieldValue.serverTimestamp(),
                                };
                                Map<String, dynamic> qrid1 = {
                                  'qrid': (slotno + vno + Userid + slottime)
                                      .toString(),
                                };
                                data.addAll(qrid1);

                                print(data);
                                String qrid = (slotno + vno + Userid + slottime)
                                    .toString();
                                try {
                                  userbook
                                      .document(Userid)
                                      .collection('Bookings')
                                      .document(qrid)
                                      .setData(userdata);

                                  book
                                      .document(widget.docId)
                                      .collection('Slotsbooked')
                                      .document(qrid)
                                      .setData(data)
                                      .then((value) => Navigator.push(
                                          (context),
                                          MaterialPageRoute(
                                              builder: (context) => MyRecipt(
                                                  qrid: qrid, docid: docId))));
                                } catch (e) {
                                  print(e);
                                  AlertDialog(
                                      title: Text('Alert'),
                                      content: Text(e),
                                      actions: <Widget>[
                                        ElevatedButton(
                                            child: Text('Ok'),
                                            onPressed: () {
                                              Navigator.of(context).pop();
                                            }),
                                      ]);
                                }
                              },
                              child: Text('Confirm Booking',
                                  style: TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight.bold)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                } else
                  return Center(
                    child: Text(''),
                  );
              },
            ),
          )
        ],
      ),
    );
  }

  @override
  void dispose() {
    _connectivity.disposeStream();
    super.dispose();
  }
}
