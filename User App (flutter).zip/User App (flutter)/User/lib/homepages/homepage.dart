import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
/*import 'package:flutter_typehead/flutter_typehead.dart';*/
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:android_intent/android_intent.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:modal_bottom_sheet/modal_bottom_sheet.dart';
import 'package:qrparking/homepages/bookingdetails.dart';

import 'package:qrparking/navigationDrawer/navigationDrawer.dart';
import 'package:connectivity/connectivity.dart';
import 'package:qrparking/internet.dart';

// ignore: camel_case_types
class CountryModels {
  String countryName;
  String countryAddress;
  double lat, lng;
  @override
  String toString() {
    return '$countryName $countryAddress $lat $lng';
  }

  CountryModels({this.countryName, this.countryAddress, this.lat, this.lng});
}

class home extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: homepage(),
    );
  }
}

// ignore: camel_case_types
class homepage extends StatefulWidget {
  final String phno;
  final String docid;

  homepage({Key key, this.phno, this.docid}) : super(key: key);
  @override
  _homepageState createState() => _homepageState(this.docid);
}

// ignore: camel_case_types
class _homepageState extends State<homepage> {
  bool isenable,Holiday;
  bool isloading = false;
  var clients = [];
  static final CameraPosition _initialLocation =
      CameraPosition(target: LatLng(15.2993, 74.1240), zoom: 10);
  GoogleMapController mapController;
  Map<MarkerId, Marker> markers = <MarkerId, Marker>{};
  Firestore firestore = Firestore.instance;
  final Geolocator _geolocator = Geolocator();
  String distances;
  Position _currentPosition;
  var currentLocation;
  final PermissionHandler permissionHandler = PermissionHandler();
  Map<PermissionGroup, PermissionStatus> permissions;
  var currentClient;
  var currentBearing;
  String docId;
  var date =
  DateFormat.yMEd().add_jms().format(DateTime.now()); //full date time
  var weekname = DateFormat.EEEE().format(DateTime.now()).toLowerCase(); //thurday
  var time = DateFormat.y().format(DateTime.now());
  var holiday;
  String Userid; //year
  final FirebaseAuth auth = FirebaseAuth.instance;

  var docid;

  Icon actionIcon = new Icon(
    Icons.search,
    color: Colors.white,
  );
  final key = new GlobalKey<ScaffoldState>();
  final TextEditingController _searchQuery = new TextEditingController();


  List<CountryModels> societiesNames = [];
  _homepageState(this.docid);
  List<CountryModels> items = [];
  String get UserId => docid;
  Map _source = {ConnectivityResult.none: false};
  MyConnectivity _connectivity = MyConnectivity.instance;


  @override
  void initState() {

    requestLocationPermission();
    _gpsService();

    populateClients();
    //line no 84
    getcurrentuserid();

    items = societiesNames;

    _connectivity.initialise();
    _connectivity.myStream.listen((source) {
      setState(() => _source = source);
    });

    super.initState();
  }

  /*Show dialog if GPS not enabled and open settings location*/
  Future _checkGps() async {
    if (!(await Geolocator().isLocationServiceEnabled())) {
      if (Theme.of(context).platform == TargetPlatform.android) {
        showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text('Location Permission'),
                content:
                    const Text('Please make sure you enable GPS and try again'),
                actions: <Widget>[
                  ElevatedButton(
                      child: Text('Ok'),
                      onPressed: () {
                        final AndroidIntent intent = AndroidIntent(
                            action:
                                'android.settings.LOCATION_SOURCE_SETTINGS');
                        intent.launch();
                        Navigator.of(context, rootNavigator: true).pop();
                      })
                ],
              );
            });
      }
    }
  }

  getcurrentuserid() async {
    final FirebaseUser user = await auth.currentUser();
    final userid = user.uid.toString();
    if (userid == null) {
      setState(() {
        Userid = UserId;
      });
    } else {
      setState(() {
        Userid = userid;
      });
    }
    // return userid;
  }

/*Check if gps service is enabled or not*/
  Future _gpsService() async {
    if (!(await Geolocator().isLocationServiceEnabled())) {
      _checkGps();
      return null;
    } else
      return _getCurrentLocation();
  }

  void populateClients() {
    firestore.collection('parkingDetails').getDocuments().then((docs) {
      if (docs.documents.isNotEmpty) {
        for (int i = 0; i < docs.documents.length; i++) {
          initMarker(docs.documents[i].data, docs.documents[i].documentID);
          clients.add(docs.documents[i].data);
        }
      }
    });
  }

  Future initMarker(markerdata, String documentID) async {
    var markerIdVal = documentID;

    double lat = double.parse(markerdata['Lat']);
    double lng = double.parse(markerdata['Lng']);
    String parkname = markerdata['name'];
    MarkerId markerId = MarkerId(markerIdVal);
    String address = markerdata['address'];

    this.setState(() {
      Marker mark = new Marker(
          markerId: markerId,
          position: new LatLng(lat, lng),
          infoWindow: new InfoWindow(title: parkname, snippet: address),
          icon: BitmapDescriptor.defaultMarker,
          visible: true,
          onTap: () {
            print(parkname + markerIdVal);
            distance(_currentPosition, markerdata);
            showMaterialModalBottomSheet(
                context: context,
                builder: (context) => Container(
                    color: Colors.white,
                    height: MediaQuery.of(context).size.height * 0.40,
                    child: bottomSheets(markerdata, markerIdVal)));
          });
      markers[markerId] = mark;
      docId = markerIdVal;
    });
    societiesNames.add(CountryModels(
        countryName: parkname, countryAddress: address, lat: lat, lng: lng));
  }

  List<CountryModels> result = [];
  void filterSearchResults(String query) {
    List<CountryModels> dummySearchList = [];
    dummySearchList.addAll(societiesNames);
    // items.clear();

    if (query.isEmpty) {
      result = societiesNames;
    } else {
      result = dummySearchList
          .where((element) => element.countryAddress
              .toLowerCase()
              .contains(query.toLowerCase()))
          .toList();
    }


    setState(() {
      items = result;
    });
  }

  Icon icons = new Icon(Icons.search);

  bool internet;
  String selected;
  AlertDialog dialog;
 // TypeAheadField();
  @override
  Widget build(BuildContext context) {

    switch (_source.keys.toList()[0]) {
      case ConnectivityResult.none:
        setState(() {
          internet=false   ;
        });

        break;
      case ConnectivityResult.mobile:
        setState(() {
          internet=true   ;
        });
        break;
      case ConnectivityResult.wifi:
        setState(() {
          internet=true   ;
        });
    }

    Container searchBar = Container(
      child: TextField(
        onChanged: (value) => filterSearchResults(value),
        controller: _searchQuery,
        autofocus: true,
        onSubmitted: (value) {
          Navigator.of(context).pop();

        },
        decoration: InputDecoration(
            labelText: "Search by loaction",
            border: OutlineInputBorder(
                borderRadius: BorderRadius.all(Radius.circular(15.0)))),
      ),
    );
    dialog = new AlertDialog(
      title: searchBar,
      content: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return items.length > 0
              ? new ListView.builder(
                  shrinkWrap: true,
                  itemCount: items.length,
                  itemBuilder: (context, int index) {
                    return Ink(
                      child: InkWell(
                        onTap: () {
                          setState(() {
                            selected = items[index].countryName;
                            Navigator.pop(context);
                          });
                          navigatesearch(items[index].lat, items[index].lng);
                        },
                        child: ListTile(
                          title: Column(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Text(
                                items[index].countryName,
                                style: TextStyle(color: Colors.blueAccent),
                              ),
                              Text(items[index].countryAddress,
                                  style: TextStyle(fontSize: 9)),
                            ],
                          ),
                        ),
                      ),
                    );
                  },
                )
              : Text("No Records");
        },
      ),

    );

    return WillPopScope(
      onWillPop: () async {
        return showDialog(
              context: context,
              builder: (BuildContext context) {
                return AlertDialog(
                  title: Text('Are you sure?'),
                  content: Text("Do you want to Exit App"),
                  actions: [
                    new TextButton(
                        onPressed: () => Navigator.of(context).pop(false),
                        child: Text('No')),
                    new TextButton(
                        onPressed: () {
                          SystemChannels.platform
                              .invokeMethod('SystemNavigator.pop');
                          Navigator.of(context).pop(true);
                        },
                        child: Text('Yes')),
                  ],
                );
              },
            ) ??
            false;
      },
      child: Scaffold(
        appBar: new AppBar(
            title: Text('Home', style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),),
            backgroundColor: Colors.blueAccent,
            elevation: 10,
            centerTitle: true,
            actions: <Widget>[
              IconButton(
                icon: icons,
                onPressed: () {
                  showDialog(
                      context: context,
                      builder: (BuildContext context) {
                        return dialog;
                      });
                },
              ),
            ]),
        drawer: navigationDrawer(),
        body: Center(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Stack(
              children: [
                GoogleMap(
                  initialCameraPosition: _initialLocation,
                  myLocationEnabled: true,
                  myLocationButtonEnabled: false,
                  mapType: MapType.normal,
                  zoomControlsEnabled: false,
                  zoomGesturesEnabled: true,
                  onMapCreated: onMapCreated,
                  //polylines: route,
                  markers: Set<Marker>.of(markers.values),
                ),

                //positionbutton
                Positioned(
                  bottom: 30,
                  left: 15,
                  child: FloatingActionButton(
                    child: Icon(Icons.my_location),
                    backgroundColor: Colors.blueAccent,
                    onPressed: () {
                      _gpsService();
                      print(markers);
                      print(clients);
                      // _getCurrentLocation();
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void onMapCreated(GoogleMapController controller) {
    setState(() {
      mapController = controller;
    });
  }

//get user locatuion
  void _getCurrentLocation() async {
    await _geolocator
        .getCurrentPosition(desiredAccuracy: LocationAccuracy.high)
        .then((position) async {
      setState(() {
        _currentPosition = position;
        print(societiesNames);
        mapController.animateCamera(
          CameraUpdate.newCameraPosition(
            CameraPosition(
              target: LatLng(
                _currentPosition.latitude,
                _currentPosition.longitude,
              ),
              zoom: 10.0,
            ),
          ),
        );
      });
    }).catchError((e) {
      print(e);
    });
  }

  void navigatesearch(double lat, double lng) {
    mapController.animateCamera(
      CameraUpdate.newCameraPosition(
        CameraPosition(
          target: LatLng(lat, lng),
          zoom: 15.0,
        ),
      ),
    );
  }

  Future<bool> _requestPermission(PermissionGroup permission) async {
    final PermissionHandler _permissionHandler = PermissionHandler();
    var result = await _permissionHandler.requestPermissions([permission]);
    if (result[permission] == PermissionStatus.granted) {
      return true;
    }
    return false;
  }
/*Checking if your App has been Given Permission*/

  Future<bool> requestLocationPermission({Function onPermissionDenied}) async {
    var granted = await _requestPermission(PermissionGroup.location);

    if (granted != true) {
      requestLocationPermission();
    }
    debugPrint('requestContactsPermission $granted');
    return granted;
  }

//bottom sheets
  bottomSheets(markerdata, documentId) {
    final String name = markerdata['name'];
    final String address = markerdata['address'];
    var slots = markerdata['slots'];
    var fee = markerdata['fee'];
    var workingday = markerdata['Workingday'];
    var endday = markerdata['Endday'];
    var starttime = markerdata['Starttime'];
    var endtime = markerdata['Endtime'];
    var upino = markerdata['phno'];
    var holiday=markers['Holiday'].toString().toLowerCase();

    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Column(
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(top: 8.0),
            child: Center(
              child: Container(
                width: 44,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey.withOpacity(0.4),
                    borderRadius: BorderRadius.circular(15)),
              ),
            ),
          ),
          //title
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: const EdgeInsets.only(left: 20.0, top: 15),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      '$name',
                      style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 20,
                        letterSpacing: 0.2,
                        color: Colors.blueAccent,
                        fontFamily: 'Roboto-Black',
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      '$address ' + '($distances)',
                      style: TextStyle(
                          fontWeight: FontWeight.w400,
                          color: Colors.black54,
                          fontSize: 12,
                          letterSpacing: 0.2),
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: <Widget>[
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Icon(
                              Icons.local_parking,
                              size: 17.5,
                              color: Colors.white,
                            ),
                          ),
                          color: Colors.blueAccent,
                          elevation: 5,
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          '$slots slots',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                        SizedBox(
                          width: 30,
                        ),
                        Card(
                          child: Padding(
                            padding: const EdgeInsets.all(2.0),
                            child: Icon(
                              Icons.attach_money,
                              size: 17.5,
                              color: Colors.white,
                            ),
                          ),
                          color: Colors.blueAccent,
                          elevation: 5,
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          'Rs. $fee/ hour',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        )
                      ],
                    ),
                    SizedBox(height: 7),
                    Row(
                      children: <Widget>[
                        GestureDetector(
                          onTap: () {
                            launch("tel:$upino");
                          },
                          child: Card(
                            child: Padding(
                              padding: const EdgeInsets.all(2.0),
                              child: Icon(
                                Icons.local_phone,
                                size: 17.5,
                                color: Colors.white,
                              ),
                            ),
                            color: Colors.blueAccent,
                            elevation: 5,
                          ),
                        ),
                        SizedBox(
                          width: 4,
                        ),
                        Text(
                          '$upino',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 13,
                          ),
                        ),
                      ],
                    ),
                    //phone number
                    SizedBox(
                      height: 7,
                    ),
                  ],
                ),
              ),
              //image of parking
              Padding(
                padding: const EdgeInsets.only(right: 18.0, top: 8),
                child: ClipRRect(
                  child: Image.asset(
                    'assets/images/qr-code.png',
                    fit: BoxFit.cover,
                    width: 120,
                    height: 120,
                  ),
                  borderRadius: BorderRadius.circular(8),
                ),
              ),
            ],
          ),
          SizedBox(
            height: 5,
          ),
          Padding(
            padding: const EdgeInsets.only(
              left: 20.0,
            ),
            child: Row(
              children: <Widget>[
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: Icon(
                      Icons.access_time,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                  color: Colors.blueAccent,
                  elevation: 5,
                ),
                SizedBox(
                  width: 4,
                ),
                Text(
                  '$starttime ' + '-' + ' $endtime',
                  style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13),
                ),
                SizedBox(
                  width: 24,
                ),
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(2.0),
                    child: Icon(
                      Icons.date_range,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                  color: Colors.blueAccent,
                  elevation: 5,
                ),
                SizedBox(
                  width: 4,
                ),
                Text(
                  '$workingday' + '-' + ' $endday',
                  style: TextStyle(
                      fontWeight: FontWeight.w600,
                      fontSize: 13,
                      color: Colors.green),
                )
              ],
            ),
          ),
          /*button*/
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 24.0, horizontal: 24),
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 55,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                    primary: Colors.blueAccent,
                    elevation: 10,
                    padding: EdgeInsets.symmetric(vertical: 14),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10.0),
                    )),
                onPressed: isenable == true
                    ? () async{
                        // Navigator.push(context, SlideTopRoute(page: MyPaymentPage()));
                        if (internet== true) {
                          Navigator.push(
                              (context),
                              MaterialPageRoute(
                                  builder: (context) => bookingdetails(
                                      docId: documentId, userid: Userid)));
                        } else {
                          Navigator.of(context).pop();
                          return showDialog(
                              context: context,
                              builder: (BuildContext context) {
                                return AlertDialog(
                                  title: Text('Internet Permission',style: TextStyle(fontWeight: FontWeight.bold),),
                                  content: const Text(
                                      'Please make sure you enable Internet and try again'),
                                  actions: <Widget>[
                                    ElevatedButton(
                                        child: Text('Ok'),
                                        onPressed: () {
                                          final AndroidIntent intent =
                                              AndroidIntent(
                                                  action: 'android.settings.SETTINGS');
                                          intent.launch();
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop();
                                        }),
                                  ],
                                );
                              });


                        }
                      }
                    : ()async{
                  Holiday != true?
                  ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content:Text('Cannot Book beyond 5km distance'),
                    backgroundColor: Colors.blueAccent,
                    behavior: SnackBarBehavior.fixed,
                    elevation: 5,
                    duration: Duration(seconds: 5),
                  )):ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                    content:Text('Today is Holiday'),
                    backgroundColor: Colors.blueAccent,
                    behavior: SnackBarBehavior.fixed,
                    elevation: 5,
                    duration: Duration(seconds: 5),
                  ));

                  return
                  Navigator.of(context).pop();},
                child: Text(
                  'BOOK SPOT',
                  style: TextStyle(
                      color: Colors.white,
                      fontSize: 16,
                      fontWeight: FontWeight.w700,
                      wordSpacing: 4,
                      letterSpacing: 0.3),
                ),
              ),
            ),
          ),
//working hours
        ],
      ),
    );
  }

  Future<void> distance(Position currentPosition, markerdata) async {
    double lat2 = double.parse(markerdata['Lat']);
    double lng2 = double.parse(markerdata['Lng']);
    var holiday=markerdata['Holiday'].toString().toLowerCase();
    double lat1 = currentPosition.latitude;
    double lng1 = currentPosition.longitude;

    double distance1 =
        await Geolocator().distanceBetween(lat1, lng1, lat2, lng2);

    if (distance1 > 4000.00) {
      setState(() {
        isenable = false;
      });
    } else {
      setState(() {
        isenable = true;
      });
    }
    if (distance1 > 1000.00) {
      double dis = distance1 / 1000;

      setState(() {
        distances = dis.toStringAsFixed(2) + 'km';
      });
    } else {
      setState(() {
        distances = distance1.toStringAsFixed(2) + 'm';
      });
    }
    if(weekname==holiday){
      setState(() {
        Holiday=true;
       // isenable = false;
      });
    }else{
      setState(() {
        Holiday = false;
      });
    }
  }
  @override
  void dispose() {
    _connectivity.disposeStream();
    super.dispose();
  }

}
