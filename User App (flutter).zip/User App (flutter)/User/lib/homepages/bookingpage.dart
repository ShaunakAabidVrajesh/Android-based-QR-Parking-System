import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:flutter/cupertino.dart';

import 'package:intl/intl.dart';
import 'package:qrparking/homepages/usersbooking.dart';


final FirebaseAuth auth = FirebaseAuth.instance;
var name, slotno, booktime, reservetime, address;
String Userid;

class userbookingsdetails extends StatefulWidget {
  @override
  _userbookingsdetailsState createState() => _userbookingsdetailsState();
}

class _userbookingsdetailsState extends State<userbookingsdetails> {
  @override
  void initState() {
    // TODO: implement initStat
    getcurrentuserid();
    //   Firebase();
    //
    super.initState();
  }

  getcurrentuserid() async {
    final FirebaseUser user = await auth.currentUser();
    final userid = user.uid.toString();
    Userid = userid;
    // return userid;
  }

  String dates = DateFormat.yMMMd().format(DateTime.now());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // drawer: navigationDrawer(),
      body: Center(
        child: Container(
          //  margin: EdgeInsets.only(top: 60),
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height * 1.5,

          child: StreamBuilder<QuerySnapshot>(
              stream: Firestore.instance
                  .collection("users")
                  .document(Userid)
                  .collection('Bookings')
                  .where('date', isEqualTo: dates)
                  .where('booking', isEqualTo: 'Confirm')
                  .snapshots(),
              builder: (BuildContext context,
                  AsyncSnapshot<QuerySnapshot> snapshot) {
                if (snapshot.hasError)
                  return new Text('Error: ${snapshot.error}');
                else if (!snapshot.hasData)
                  return new Center(
                      child:
                          Text('Either no Bookings done today or Cancelled'));
                switch (snapshot.connectionState) {
                  case ConnectionState.waiting:
                    return Center(child: new Text('Loading...'));
                  default:
                    return new GridView(
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        // childAspectRatio: 0.60,
                        mainAxisSpacing: 15,
                        crossAxisSpacing: 15,
                      ),
                      padding: EdgeInsets.all(20),
                      scrollDirection: Axis.vertical,
                      children: snapshot.data.documents
                          .map((DocumentSnapshot document) {
                        return new CustomCard(
                          name:
                              document['parkingname'].toString().toUpperCase(),
                          booktime: document['booktime'],
                          reserve: document['reserve'],
                          slotno: document['slotno'],
                          address: document['address'],
                          date: document['date'],
                          qrid: document['qrid'],
                          vehicleno: document['vehicleno'],
                          parked: document['parked'],
                          booking: document['booking'],
                          userid: Userid,
                          checkout: document['checkout'],
                          checkin:document['checkedin'] ,
                        );
                      }).toList(),
                    );
                }
              }),
        ),
      ),
    );
  }
}
