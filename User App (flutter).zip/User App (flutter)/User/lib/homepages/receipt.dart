
import 'dart:core';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/cupertino.dart';

import 'package:qrparking/homepages/homepage.dart';


// ignore: must_be_immutable
class MyRecipt extends StatefulWidget{
String qrid;var docid;
MyRecipt({Key key,this.qrid, this.docid }) : super(key: key);
  @override
  State createState() => _MyReciptState(this.qrid, this.docid );
}

class _MyReciptState extends State<MyRecipt> {
String phonenumber;
var qrid,docid;
  _MyReciptState( this.qrid,this.docid);
String get Qrid=>qrid;String get Docid=>docid;final FirebaseAuth auth=FirebaseAuth.instance;
var name,slotno,booktime,reservetime,address;String Userid;
  @override
  void initState() {
    // TODO: implement initStat
    getcurrentuserid();
    Firebase();

    //
    super.initState();
  }
  userno(String user) async{
    Firestore.instance.collection('users').document(user).get().
    then((value) {
      setState(() {
        phonenumber= value.data['mobileno'];
      });
    });
  }

  getcurrentuserid() async{
    final FirebaseUser user=await auth.currentUser();
    final userid=user.uid.toString();
   Userid=userid;
    userno(userid);

  }
  Firebase() async{


    try{
      DocumentReference db=Firestore.instance.collection('parkingDetails').document(Docid).collection('Slotsbooked').document(Qrid);
      db.get().then((value) => {
        if(value.exists){
          setState(() {
            name=value.data['parkingname'];
            slotno=value.data['slotno'];
            booktime=value.data['booktime'];
            reservetime=value.data['reserve'];
            address=value.data['address'];


          }),
          print(slotno),print(name),print(Userid),


        }
        else {
          AlertDialog(
            title: Text('$Qrid'),
                content:const Text('No data found'),
          actions: <Widget>[
              ElevatedButton(child: Text('Ok'),
            onPressed: () {Navigator.of(context).pop();})],)
        }
      });
    }catch(e){print(e);}

  }
  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: ()async=>false,
      child: Scaffold(
        backgroundColor: Colors.white,
        appBar: AppBar(
          automaticallyImplyLeading: false,
          title: Text(
            "Booking Reciept",
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          backgroundColor: Colors.blueAccent,
          elevation: 0,
          centerTitle: true,
          textTheme: Theme
              .of(context)
              .textTheme,
        ),

        body: SafeArea(
          child: SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 18.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  SizedBox(height: 30,),
                  Center(
                    child: QrImage(
                      data: Qrid,
                      version: QrVersions.auto,
                      size: 200.0,
                    ),
                  ),

                  SizedBox(height: 50,),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 18.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Parking Name',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13
                              ),
                            ),
                            SizedBox(height: 8,),
                            Text(
                              '$name',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 32
                              ),
                            ),
                          ],
                        ),


                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'Parking Slot',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13
                              ),
                            ),
                            SizedBox(height: 8,),
                            Text(
                              '$slotno',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 32
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),

                  SizedBox(height: 25,),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 18.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'From',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13
                              ),
                            ),
                            SizedBox(height: 8,),
                            Text(
                              '$booktime',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 20
                              ),
                            ),
                          ],
                        ),


                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text(
                              'To',
                              style: TextStyle(
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[400],
                                  fontSize: 13
                              ),
                            ),
                            SizedBox(height: 8,),
                            Text(
                              '$reservetime',
                              style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                  fontSize: 20
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),


                  SizedBox(height: 25,),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      'Full Address',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: Colors.grey[400],
                          fontSize: 13,
                          letterSpacing: 0.2
                      ),
                    ),
                  ),
                  SizedBox(height: 8,),
                  Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Text(
                      '$address',
                      style: TextStyle(
                          fontWeight: FontWeight.w700,
                          color: Colors.grey[900],
                          fontSize: 16.4,
                          letterSpacing: 0.2
                      ),
                    ),
                  ),



                  SizedBox(height: 50,),
                  Padding(
                    padding:const EdgeInsets.all(15),
                    child: Container(
                      height:57,
                      width: double.infinity ,
                      child: ElevatedButton(
                        style: ElevatedButton.styleFrom(
                            primary: Colors.blueAccent,
                            elevation: 10,
                            shape: RoundedRectangleBorder(
                              borderRadius:
                              BorderRadius.circular(10.0),
                            )),
                        onPressed: (){
                          Navigator.push((context),MaterialPageRoute( builder: (context) =>
                              homepage()));
                        },
                        child: Text(
                          'Move to Home page',
                          style: TextStyle(
                              color: Colors.white,
                              fontSize: 16,
                              fontWeight: FontWeight.w700,
                              wordSpacing: 2,
                              letterSpacing: 0.4
                          ),
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}